package com.plasma.companion.entity;

import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.core.particles.ParticleTypes;
import com.plasma.companion.registry.PlasmaBlocks;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkHooks;

import java.util.List;

/** PLASMA companion with simple, bounded work orders. */
public class PlasmaEntity extends TamableAnimal {
    public enum Mode {
        FOLLOW, STAY, GUARD, FARM, MILK, MINE, BUILD;

        public Mode nextCommand() {
            return switch (this) {
                case FOLLOW -> STAY;
                case STAY -> GUARD;
                default -> FOLLOW;
            };
        }

        public String displayName() {
            return switch (this) {
                case FOLLOW -> "Seguir";
                case STAY -> "Quedarse";
                case GUARD -> "Proteger zona";
                case FARM -> "Trabajar: cultivar";
                case MILK -> "Trabajar: ordeñar";
                case MINE -> "Trabajar: minar";
                case BUILD -> "Trabajar: construir casa";
            };
        }

        public boolean isWorkOrder() {
            return this == FARM || this == MILK || this == MINE || this == BUILD;
        }
    }

    public enum Stage { LARVA, COCOON, LEGGED_LARVA, PUPA, YOUNG, MANIA, ADULT }
    private static final EntityDataAccessor<Integer> STAGE = SynchedEntityData.defineId(PlasmaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> STALKER = SynchedEntityData.defineId(PlasmaEntity.class, EntityDataSerializers.BOOLEAN);

    private final SimpleContainer plasmaInventory = new SimpleContainer(9);
    private Mode mode = Mode.FOLLOW;
    private BlockPos workAnchor = BlockPos.ZERO;
    private BlockPos homePos = BlockPos.ZERO;
    private boolean hasWorkAnchor = false;
    private boolean hasHome = false;
    private int milkCooldown = 0;
    private int mineCooldown = 0;
    private int buildStep = 0;
    private int stageTicks = 0;
    private int stalkerSeenTicks = 0;
    private int eatAnimationTicks = 0;

    public PlasmaEntity(EntityType<? extends PlasmaEntity> type, Level level) {
        super(type, level);
        this.setCustomName(Component.literal("PLASMA"));
        this.setMaxUpStep(1.25F);
        if (this.getNavigation() instanceof GroundPathNavigation nav) nav.setCanOpenDoors(true);
        this.entityData.set(STAGE, Stage.ADULT.ordinal());
        this.entityData.set(STALKER, false);
        this.setCustomNameVisible(false);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STAGE, Stage.ADULT.ordinal());
        this.entityData.define(STALKER, false);
    }

    public Stage getStage() { return Stage.values()[Math.floorMod(this.entityData.get(STAGE), Stage.values().length)]; }
    public void setStage(Stage stage) {
        this.entityData.set(STAGE, stage.ordinal());
        this.stageTicks = 0;
        if (this.getAttribute(Attributes.MAX_HEALTH) != null) {
            double hp = switch (stage) { case LARVA -> 8.0D; case COCOON -> 12.0D; case LEGGED_LARVA -> 18.0D; case PUPA -> 24.0D; case YOUNG -> 42.0D; case MANIA -> 58.0D; case ADULT -> 80.0D; };
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(hp);
            this.setHealth((float) hp);
        }
        if (this.getAttribute(Attributes.MOVEMENT_SPEED) != null) {
            double speed = switch (stage) { case LARVA, COCOON, PUPA -> 0.08D; case LEGGED_LARVA -> 0.19D; case YOUNG -> 0.27D; case MANIA -> 0.33D; case ADULT -> 0.34D; };
            this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(speed);
        }
        if (this.getAttribute(Attributes.ATTACK_DAMAGE) != null) {
            double damage = stage == Stage.ADULT ? 14.0D : 0.0D;
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(damage);
        }
        this.refreshDimensions();
    }
    public boolean isStalker() { return this.entityData.get(STALKER); }
    public void setStalker(boolean value) { this.entityData.set(STALKER, value); if (value) { this.setCustomName(Component.literal("???")); this.setCustomNameVisible(false); } }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 36.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.31D)
                .add(Attributes.ATTACK_DAMAGE, 7.0D)
                .add(Attributes.ARMOR, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 28.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.25D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.25D, true) {
            @Override public boolean canUse() { return !isStalker() && getStage() == Stage.ADULT && super.canUse(); }
            @Override public boolean canContinueToUse() { return !isStalker() && getStage() == Stage.ADULT && super.canContinueToUse(); }
        });
        this.goalSelector.addGoal(3, new FollowInFollowModeGoal());
        this.goalSelector.addGoal(4, new WanderInFollowModeGoal());
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Monster.class,
                10, true, false, target -> this.isTame() && this.mode == Mode.GUARD));
    }

    private class WanderInFollowModeGoal extends WaterAvoidingRandomStrollGoal {
        private WanderInFollowModeGoal() { super(PlasmaEntity.this, 0.95D); }
        @Override public boolean canUse() { return mode == Mode.FOLLOW && super.canUse(); }
        @Override public boolean canContinueToUse() { return mode == Mode.FOLLOW && super.canContinueToUse(); }
    }

    private class FollowInFollowModeGoal extends FollowOwnerGoal {
        private FollowInFollowModeGoal() { super(PlasmaEntity.this, 1.2D, 6.0F, 2.2F, false); }
        @Override public boolean canUse() { return mode == Mode.FOLLOW && super.canUse(); }
        @Override public boolean canContinueToUse() { return mode == Mode.FOLLOW && super.canContinueToUse(); }
    }

    public Mode getMode() { return mode; }
    public BlockPos getHomePos() { return hasHome ? homePos : null; }
    public int getEatAnimationTicks() { return eatAnimationTicks; }

    private void setMode(Mode newMode) {
        this.mode = newMode;
        boolean sit = newMode == Mode.STAY;
        this.setOrderedToSit(sit);
        this.setInSittingPose(sit);
        this.navigation.stop();
    }

    private void setWorkOrder(Player owner, Mode workMode) {
        Direction facing = owner.getDirection();
        this.workAnchor = owner.blockPosition().relative(facing, workMode == Mode.BUILD ? 3 : 0);
        this.hasWorkAnchor = true;
        if (workMode == Mode.BUILD) {
            this.buildStep = 0;
            this.hasHome = false;
        }
        this.setMode(workMode);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        boolean clientSide = this.level().isClientSide;

        if (this.getStage() == Stage.LARVA && held.is(PlasmaItems.PLASMA_GROWTH_MASH.get())) {
            if (!clientSide) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                this.setStage(Stage.COCOON);
                this.setCustomName(Component.literal("PLASMA | Crisálida"));
                player.displayClientMessage(Component.literal("PLASMA se ha encerrado en una crisálida. Déjala bajo el sol durante un minuto."), true);
            }
            return InteractionResult.sidedSuccess(clientSide);
        }
        if (this.getStage() == Stage.LEGGED_LARVA && held.is(PlasmaItems.PLASMA_GROWTH_MASH.get())) {
            BlockPos nest = BlockPos.findClosestMatch(this.blockPosition(), 4, 3, p -> this.level().getBlockState(p).is(PlasmaBlocks.PLASMA_NEST.get())).orElse(null);
            if (nest != null && !clientSide) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                this.setStage(Stage.PUPA);
                this.setCustomName(Component.literal("PLASMA | Pupa"));
                this.navigation.stop();
                player.displayClientMessage(Component.literal("La pupa está en el nido. ¡Protégela de los infectados!"), true);
            }
            return InteractionResult.sidedSuccess(clientSide);
        }
        if (!this.isTame() && (held.is(PlasmaItems.PLASMA_CORE.get()) || held.is(PlasmaItems.CHAOS_BERRY.get()))) {
            if (!clientSide) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                this.tame(player);
                player.getPersistentData().putBoolean("PlasmaEverAdopted", true);
                this.setCustomNameVisible(true);
                this.setMode(Mode.FOLLOW);
                this.spawnTamingParticles(true);
                player.displayClientMessage(Component.literal("PLASMA: ...bien. Te seguiré."), true);
            }
            return InteractionResult.sidedSuccess(clientSide);
        }

        if (this.isTame() && this.isOwnedBy(player)) {
            if (held.isEdible() && this.getStage() == Stage.ADULT) {
                if (!clientSide) {
                    this.heal(6.0F);
                    if (!player.getAbilities().instabuild) held.shrink(1);
                    this.eatAnimationTicks = 40;
                    this.setInSittingPose(true);
                    player.displayClientMessage(Component.literal("PLASMA se sienta a comer. No necesita alimento para sobrevivir."), true);
                }
                return InteractionResult.sidedSuccess(clientSide);
            }

            Mode requested = requestedWorkMode(held);
            if (requested != null) {
                if (!clientSide) {
                    int amount = requested == Mode.MINE || requested == Mode.MILK ? 1 : held.getCount();
                    int moved = transferHeldStack(player, held, amount);
                    if (moved > 0) {
                        setWorkOrder(player, requested);
                        player.displayClientMessage(Component.literal("PLASMA: " + requested.displayName() + ". Marca de trabajo establecida."), true);
                    } else {
                        player.displayClientMessage(Component.literal("PLASMA: necesito espacio en mi mochila para esa herramienta o material."), true);
                    }
                }
                return InteractionResult.sidedSuccess(clientSide);
            }

            if (player.isCrouching() && held.isEmpty()) {
                if (!clientSide) {
                    this.setMode(this.mode.nextCommand());
                    player.displayClientMessage(Component.literal("PLASMA: modo " + this.mode.displayName()), true);
                }
                return InteractionResult.sidedSuccess(clientSide);
            }

            if (held.isEmpty() && !player.isCrouching()) {
                if (!clientSide && player instanceof ServerPlayer serverPlayer) {
                    NetworkHooks.openScreen(serverPlayer,
                            new net.minecraft.world.SimpleMenuProvider(
                                    (id, inventory, p) -> new ChestMenu(MenuType.GENERIC_9x1, id, inventory, plasmaInventory, 1),
                                    Component.literal("PLASMA | Mochila")));
                }
                return InteractionResult.sidedSuccess(clientSide);
            }
        }
        return super.mobInteract(player, hand);
    }

    private Mode requestedWorkMode(ItemStack held) {
        if (held.is(Items.BUCKET)) return Mode.MILK;
        if (held.getItem() instanceof PickaxeItem) return Mode.MINE;
        if (held.getItem() instanceof HoeItem || isPlantingItem(held.getItem())) return Mode.FARM;
        if (isBuildingMaterial(held)) return Mode.BUILD;
        return null;
    }

    private int transferHeldStack(Player player, ItemStack held, int requested) {
        if (held.isEmpty() || requested <= 0) return 0;
        int offeredCount = Math.min(requested, held.getCount());
        ItemStack offered = held.copy();
        offered.setCount(offeredCount);
        ItemStack remainder = this.plasmaInventory.addItem(offered);
        int moved = offeredCount - remainder.getCount();
        if (moved > 0 && !player.getAbilities().instabuild) held.shrink(moved);
        return moved;
    }

    private static boolean isPlantingItem(Item item) {
        return item == Items.WHEAT_SEEDS || item == Items.CARROT || item == Items.POTATO || item == Items.BEETROOT_SEEDS;
    }

    private static boolean isBuildingMaterial(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem)) return false;
        Block block = Block.byItem(stack.getItem());
        BlockState state = block.defaultBlockState();
        return state.is(BlockTags.PLANKS) || state.is(BlockTags.LOGS)
                || block == Blocks.COBBLESTONE || block == Blocks.MOSSY_COBBLESTONE
                || block == Blocks.STONE_BRICKS || block == Blocks.MOSSY_STONE_BRICKS
                || block == Blocks.BRICKS;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            if (this.getStage() != Stage.COCOON || (this.level().isDay() && this.level().canSeeSky(this.blockPosition()))) stageTicks++;
            tickGrowthStage();
            if (isStalker()) tickStalker();
            if (milkCooldown > 0) milkCooldown--;
            if (mineCooldown > 0) mineCooldown--;
            if (eatAnimationTicks > 0) eatAnimationTicks--;
            else if (this.getStage() == Stage.ADULT && this.mode != Mode.STAY) this.setInSittingPose(false);
        }
        if (!this.level().isClientSide && this.isTame() && !isStalker() && this.getStage() == Stage.ADULT && this.tickCount % 10 == 0) {
            if (this.mode != Mode.STAY) collectNearbyItems();
            if (this.mode.isWorkOrder() && this.hasWorkAnchor && this.level() instanceof ServerLevel serverLevel) {
                if (this.tickCount % 40 == 0) processWorkOrder(serverLevel);
            }
        }
    }

    private void tickGrowthStage() {
        if (this.getStage() == Stage.COCOON) {
            if (this.level().isDay() && this.level().canSeeSky(this.blockPosition()) && stageTicks >= 1200) {
                this.setStage(Stage.LEGGED_LARVA);
                this.setCustomName(Component.literal("PLASMA | Larva oscura"));
                this.level().broadcastEntityEvent(this, (byte) 7);
            }
        }
        if (this.getStage() == Stage.PUPA && this.level() instanceof ServerLevel server) {
            if (stageTicks % 240 == 0 && stageTicks < 2400) {
                for (int i = 0; i < 2; i++) {
                    net.minecraft.world.entity.monster.Zombie zombie = net.minecraft.world.entity.EntityType.ZOMBIE.create(server);
                    if (zombie != null) {
                        double a = this.random.nextDouble() * Math.PI * 2.0D;
                        BlockPos p = BlockPos.containing(this.getX() + Math.cos(a) * 7.0D, this.getY(), this.getZ() + Math.sin(a) * 7.0D);
                        p = server.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, p);
                        zombie.moveTo(p.getX()+0.5D, p.getY(), p.getZ()+0.5D, this.random.nextFloat()*360.0F, 0);
                        server.addFreshEntity(zombie);
                    }
                }
            }
            if (stageTicks >= 2400) {
                this.setStage(Stage.YOUNG);
                this.setCustomName(Component.literal("PLASMA Joven"));
                server.sendParticles(ParticleTypes.HEART, getX(), getY()+1.0D, getZ(), 12, .6, .5, .6, .02);
            }
        }
        if (this.getStage() == Stage.MANIA && stageTicks >= 12000) {
            this.setStage(Stage.ADULT);
            this.setCustomName(Component.literal("PLASMA"));
            this.setCustomNameVisible(true);
        }
    }

    private void tickStalker() {
        if (!(this.level() instanceof ServerLevel server)) return;
        Player player = server.getNearestPlayer(this, 32.0D);
        if (player != null && player.hasLineOfSight(this)) {
            stalkerSeenTicks++;
            if (stalkerSeenTicks == 1) {
                server.playSound(null, this.blockPosition(), net.minecraft.sounds.SoundEvents.SCULK_SHRIEKER_SHRIEK,
                        net.minecraft.sounds.SoundSource.HOSTILE, 0.75F, 0.72F);
                player.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.DARKNESS, 30, 0, true, false));
            }
            if (stalkerSeenTicks > 12) { this.discard(); return; }
        }
        if (this.tickCount > 600) {
            BlockPos giftPos = player != null && player.getRespawnPosition() != null ? player.getRespawnPosition() : (player != null ? player.blockPosition() : this.blockPosition());
            if (player != null && player.getRespawnPosition() != null && player.getRespawnDimension() != server.dimension()) giftPos = player.blockPosition();
            net.minecraft.world.entity.item.ItemEntity gift = new net.minecraft.world.entity.item.ItemEntity(server,
                    giftPos.getX()+0.5D, giftPos.getY()+1.0D, giftPos.getZ()+0.5D,
                    new ItemStack(PlasmaItems.CHAOS_SHARD.get(), 1 + this.random.nextInt(2)));
            server.addFreshEntity(gift);
            this.discard();
        }
    }

    private void processWorkOrder(ServerLevel level) {
        switch (this.mode) {
            case FARM -> workFarm(level);
            case MILK -> workMilk(level);
            case MINE -> workMine(level);
            case BUILD -> workBuild(level);
            default -> { }
        }
    }

    private void workFarm(ServerLevel level) {
        BlockPos min = workAnchor.offset(-6, -2, -6);
        BlockPos max = workAnchor.offset(6, 2, 6);
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            BlockState state = level.getBlockState(pos);
            if (state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state)) {
                List<ItemStack> drops = Block.getDrops(state, level, pos, level.getBlockEntity(pos), this, ItemStack.EMPTY);
                for (ItemStack drop : drops) storeOrDrop(drop, level);
                level.setBlock(pos, crop.defaultBlockState(), 3);
                return;
            }
        }

        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (!level.getBlockState(pos).is(Blocks.FARMLAND)) continue;
            BlockPos cropPos = pos.above();
            if (!level.isEmptyBlock(cropPos)) continue;
            for (int slot = 0; slot < plasmaInventory.getContainerSize(); slot++) {
                ItemStack seed = plasmaInventory.getItem(slot);
                Block crop = cropForSeed(seed.getItem());
                if (crop != null) {
                    level.setBlock(cropPos, crop.defaultBlockState(), 3);
                    seed.shrink(1);
                    return;
                }
            }
        }

        // If the owner also supplied a hoe, prepare nearby dirt for later planting.
        boolean hasHoe = false;
        for (int i = 0; i < plasmaInventory.getContainerSize(); i++) {
            if (plasmaInventory.getItem(i).getItem() instanceof HoeItem) {
                hasHoe = true;
                break;
            }
        }
        if (hasHoe) {
            for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
                BlockState soil = level.getBlockState(pos);
                BlockPos above = pos.above();
                if (level.isEmptyBlock(above) && (soil.is(BlockTags.DIRT)
                        || soil.is(Blocks.GRASS_BLOCK) || soil.is(Blocks.MOSS_BLOCK))) {
                    level.setBlock(pos, Blocks.FARMLAND.defaultBlockState(), 3);
                    return;
                }
            }
        }
    }

    private static Block cropForSeed(Item item) {
        if (item == Items.WHEAT_SEEDS) return Blocks.WHEAT;
        if (item == Items.CARROT) return Blocks.CARROTS;
        if (item == Items.POTATO) return Blocks.POTATOES;
        if (item == Items.BEETROOT_SEEDS) return Blocks.BEETROOTS;
        return null;
    }

    private void workMilk(ServerLevel level) {
        if (milkCooldown > 0) return;
        int bucketSlot = -1;
        for (int i = 0; i < plasmaInventory.getContainerSize(); i++) {
            if (plasmaInventory.getItem(i).is(Items.BUCKET)) { bucketSlot = i; break; }
        }
        if (bucketSlot < 0) return;
        AABB area = new AABB(workAnchor).inflate(8.0D, 4.0D, 8.0D);
        List<Cow> cows = level.getEntitiesOfClass(Cow.class, area, cow -> cow.isAlive() && !cow.isBaby());
        if (cows.isEmpty()) return;
        plasmaInventory.setItem(bucketSlot, new ItemStack(Items.MILK_BUCKET));
        milkCooldown = 1200;
    }

    private void workMine(ServerLevel level) {
        if (mineCooldown > 0) return;
        ItemStack pickaxe = ItemStack.EMPTY;
        for (int i = 0; i < plasmaInventory.getContainerSize(); i++) {
            if (plasmaInventory.getItem(i).getItem() instanceof PickaxeItem) {
                pickaxe = plasmaInventory.getItem(i);
                break;
            }
        }
        if (pickaxe.isEmpty()) return;
        BlockPos best = null;
        int bestScore = Integer.MAX_VALUE;
        BlockPos min = workAnchor.offset(-6, -4, -6);
        BlockPos max = workAnchor.offset(6, 4, 6);
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            BlockState state = level.getBlockState(pos);
            if (!isOre(state)) continue;
            int score = pos.distManhattan(workAnchor);
            if (score < bestScore) { bestScore = score; best = pos.immutable(); }
        }
        if (best == null) return;
        BlockState ore = level.getBlockState(best);
        List<ItemStack> drops = Block.getDrops(ore, level, best, level.getBlockEntity(best), this, pickaxe);
        for (ItemStack drop : drops) storeOrDrop(drop, level);
        level.setBlock(best, Blocks.AIR.defaultBlockState(), 3);
        mineCooldown = 200;
    }

    private static boolean isOre(BlockState state) {
        return state.is(BlockTags.COAL_ORES) || state.is(BlockTags.IRON_ORES)
                || state.is(BlockTags.COPPER_ORES) || state.is(BlockTags.GOLD_ORES)
                || state.is(BlockTags.REDSTONE_ORES) || state.is(BlockTags.LAPIS_ORES)
                || state.is(BlockTags.DIAMOND_ORES) || state.is(BlockTags.EMERALD_ORES);
    }

    private void workBuild(ServerLevel level) {
        BlockPos base = workAnchor;
        while (buildStep < 32) {
            BlockPos target = houseBlockAt(base, buildStep++);
            if (!level.isEmptyBlock(target)) continue;
            ItemStack material = findBuildingStack();
            if (material.isEmpty()) {
                buildStep--;
                return;
            }
            Block block = Block.byItem(material.getItem());
            BlockState state = block.defaultBlockState();
            if (state.isAir() || !state.canSurvive(level, target)) continue;
            level.setBlock(target, state, 3);
            material.shrink(1);
            return;
        }
        this.homePos = base;
        this.hasHome = true;
        this.setMode(Mode.FOLLOW);
        Player owner = this.getOwner() instanceof Player p ? p : null;
        if (owner != null) owner.displayClientMessage(Component.literal("PLASMA: refugio levantado. Lo recordaré como mi base."), true);
    }

    private static BlockPos houseBlockAt(BlockPos base, int step) {
        if (step < 9) {
            int x = (step % 3) - 1;
            int z = (step / 3) - 1;
            return base.offset(x, 0, z);
        }
        step -= 9;
        if (step < 14) {
            int level = step / 7 + 1;
            int edgeIndex = step % 7;
            int[][] perimeter = {{-1,-1},{0,-1},{1,-1},{-1,0},{1,0},{-1,1},{1,1}};
            int x = perimeter[edgeIndex][0];
            int z = perimeter[edgeIndex][1];
            return base.offset(x, level, z);
        }
        step -= 14;
        int x = (step % 3) - 1;
        int z = (step / 3) - 1;
        return base.offset(x, 3, z);
    }

    private ItemStack findBuildingStack() {
        for (int i = 0; i < plasmaInventory.getContainerSize(); i++) {
            ItemStack stack = plasmaInventory.getItem(i);
            if (isBuildingMaterial(stack)) return stack;
        }
        return ItemStack.EMPTY;
    }

    private void storeOrDrop(ItemStack stack, ServerLevel level) {
        if (stack.isEmpty()) return;
        ItemStack remaining = plasmaInventory.addItem(stack.copy());
        if (!remaining.isEmpty()) this.spawnAtLocation(remaining);
    }

    private void collectNearbyItems() {
        AABB area = this.getBoundingBox().inflate(1.5D, 1.0D, 1.5D);
        for (ItemEntity itemEntity : this.level().getEntitiesOfClass(ItemEntity.class, area, ItemEntity::isAlive)) {
            if (itemEntity.hasPickUpDelay()) continue;
            ItemStack remaining = this.plasmaInventory.addItem(itemEntity.getItem().copy());
            if (remaining.isEmpty()) itemEntity.discard();
            else if (remaining.getCount() < itemEntity.getItem().getCount()) itemEntity.setItem(remaining);
        }
    }

    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        if (!this.level().isClientSide) {
            for (int slot = 0; slot < this.plasmaInventory.getContainerSize(); slot++) {
                ItemStack stack = this.plasmaInventory.getItem(slot);
                if (!stack.isEmpty()) this.spawnAtLocation(stack.copy());
            }
            this.plasmaInventory.clearContent();
        }
        super.die(source);
    }

    @Override public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) { return null; }
    @Override public boolean isFood(ItemStack stack) { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("PlasmaMode", this.mode.name());
        tag.putInt("PlasmaStage", this.getStage().ordinal());
        tag.putInt("PlasmaStageTicks", stageTicks);
        tag.putBoolean("PlasmaStalker", isStalker());
        tag.putInt("PlasmaStalkerSeen", stalkerSeenTicks);
        tag.putInt("PlasmaEatTicks", eatAnimationTicks);
        tag.putBoolean("HasWorkAnchor", hasWorkAnchor);
        if (hasWorkAnchor) { tag.putInt("WorkX", workAnchor.getX()); tag.putInt("WorkY", workAnchor.getY()); tag.putInt("WorkZ", workAnchor.getZ()); }
        tag.putBoolean("HasHome", hasHome);
        if (hasHome) { tag.putInt("HomeX", homePos.getX()); tag.putInt("HomeY", homePos.getY()); tag.putInt("HomeZ", homePos.getZ()); }
        tag.putInt("MilkCooldown", milkCooldown);
        tag.putInt("MineCooldown", mineCooldown);
        tag.putInt("BuildStep", buildStep);
        ListTag items = new ListTag();
        for (int slot = 0; slot < plasmaInventory.getContainerSize(); slot++) {
            ItemStack stack = plasmaInventory.getItem(slot);
            if (!stack.isEmpty()) {
                CompoundTag entry = new CompoundTag();
                entry.putByte("Slot", (byte) slot);
                entry.put("Stack", stack.save(new CompoundTag()));
                items.add(entry);
            }
        }
        tag.put("PlasmaInventory", items);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        try { this.mode = Mode.valueOf(tag.getString("PlasmaMode")); }
        catch (IllegalArgumentException ignored) { this.mode = Mode.FOLLOW; }
        setStage(Stage.values()[Math.floorMod(tag.getInt("PlasmaStage"), Stage.values().length)]);
        stageTicks = Math.max(0, tag.getInt("PlasmaStageTicks"));
        setStalker(tag.getBoolean("PlasmaStalker"));
        stalkerSeenTicks = tag.getInt("PlasmaStalkerSeen");
        eatAnimationTicks = Math.max(0, tag.getInt("PlasmaEatTicks"));
        this.hasWorkAnchor = tag.getBoolean("HasWorkAnchor");
        if (hasWorkAnchor) this.workAnchor = new BlockPos(tag.getInt("WorkX"), tag.getInt("WorkY"), tag.getInt("WorkZ"));
        this.hasHome = tag.getBoolean("HasHome");
        if (hasHome) this.homePos = new BlockPos(tag.getInt("HomeX"), tag.getInt("HomeY"), tag.getInt("HomeZ"));
        this.milkCooldown = Math.max(0, tag.getInt("MilkCooldown"));
        this.mineCooldown = Math.max(0, tag.getInt("MineCooldown"));
        this.buildStep = tag.getInt("BuildStep");
        this.plasmaInventory.clearContent();
        ListTag items = tag.getList("PlasmaInventory", 10);
        for (int i = 0; i < items.size(); i++) {
            CompoundTag entry = items.getCompound(i);
            int slot = entry.getByte("Slot") & 255;
            if (slot < plasmaInventory.getContainerSize()) plasmaInventory.setItem(slot, ItemStack.of(entry.getCompound("Stack")));
        }
        boolean sit = this.mode == Mode.STAY;
        this.setOrderedToSit(sit);
        this.setInSittingPose(sit);
    }
}
