package com.plasma.companion.block;

import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class ScreamingTreeBlock extends Block {
    public ScreamingTreeBlock(Properties properties) { super(properties); }
    @Override public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        super.stepOn(level, pos, state, entity);
        if (!level.isClientSide && level.random.nextInt(35) == 0) {
            level.playSound(null, pos, SoundEvents.WARDEN_ROAR, SoundSource.BLOCKS, 0.65F, 0.8F + level.random.nextFloat() * 0.35F);
            if (entity instanceof Player player) player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 70, 0, false, true));
        }
    }
}
