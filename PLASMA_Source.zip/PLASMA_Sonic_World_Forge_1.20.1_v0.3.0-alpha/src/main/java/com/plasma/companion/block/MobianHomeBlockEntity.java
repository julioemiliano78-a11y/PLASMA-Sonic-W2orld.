package com.plasma.companion.block;

import com.plasma.companion.entity.MobianEntity;
import com.plasma.companion.registry.PlasmaBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

public class MobianHomeBlockEntity extends BlockEntity {
    private int capacity = 2;
    private int heartTimer = 0;
    public MobianHomeBlockEntity(BlockPos pos, BlockState state) { super(PlasmaBlockEntities.MOBIAN_HOME.get(), pos, state); }
    public int getCapacity() { return capacity; }
    public boolean upgrade() {
        if (capacity >= 12) return false;
        capacity = Math.min(12, capacity + 2);
        setChanged();
        return true;
    }
    public static void serverTick(Level level, BlockPos pos, BlockState state, MobianHomeBlockEntity home) {
        if (!(level instanceof ServerLevel server) || server.getGameTime() % 40L != 0L) return;
        AABB area = new AABB(pos).inflate(6.0D, 3.0D, 6.0D);
        long residents = server.getEntitiesOfClass(MobianEntity.class, area,
                m -> m.isAlive() && m.isTame() && pos.equals(m.getHomePos())).size();
        if (residents > 0) {
            server.sendParticles(ParticleTypes.HEART, pos.getX() + 0.5D, pos.getY() + 2.25D, pos.getZ() + 0.5D,
                    Math.min(3, (int) residents), 0.35D, 0.25D, 0.35D, 0.01D);
        }
    }
    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Capacity", capacity);
    }
    @Override public void load(CompoundTag tag) {
        super.load(tag);
        capacity = Math.max(2, Math.min(12, tag.getInt("Capacity")));
    }
}
