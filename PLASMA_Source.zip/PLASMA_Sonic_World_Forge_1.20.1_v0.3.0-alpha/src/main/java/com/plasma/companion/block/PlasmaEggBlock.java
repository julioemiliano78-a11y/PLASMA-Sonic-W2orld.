package com.plasma.companion.block;

import com.plasma.companion.entity.PlasmaEntity;
import com.plasma.companion.registry.PlasmaEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class PlasmaEggBlock extends Block {
    public PlasmaEggBlock(Properties properties) { super(properties); }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moving) {
        super.onPlace(state, level, pos, oldState, moving);
        if (!level.isClientSide && !oldState.is(this)) level.scheduleTick(pos, this, 1200);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!level.getBlockState(pos).is(this)) return;
        PlasmaEntity larva = PlasmaEntities.PLASMA.get().create(level);
        if (larva != null) {
            larva.moveTo(pos.getX() + 0.5D, pos.getY() + 0.1D, pos.getZ() + 0.5D, random.nextFloat() * 360.0F, 0.0F);
            larva.setStage(PlasmaEntity.Stage.LARVA);
            larva.setCustomName(net.minecraft.network.chat.Component.literal("PLASMA | Larva"));
            level.addFreshEntity(larva);
        }
        level.destroyBlock(pos, false);
    }
}
