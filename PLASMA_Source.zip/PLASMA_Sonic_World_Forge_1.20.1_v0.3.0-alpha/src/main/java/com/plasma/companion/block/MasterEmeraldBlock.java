package com.plasma.companion.block;

import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

public class MasterEmeraldBlock extends Block {
    public static final IntegerProperty LEVEL = IntegerProperty.create("level", 0, 7);
    public MasterEmeraldBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(LEVEL, 0));
    }
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) { builder.add(LEVEL); }
    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(PlasmaItems.CHAOS_EMERALD.get()) && state.getValue(LEVEL) < 7) {
            if (!level.isClientSide) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                int next = state.getValue(LEVEL) + 1;
                level.setBlock(pos, state.setValue(LEVEL, next), 3);
                buildSanctuaryUpgrade(level, pos, next);
                player.displayClientMessage(Component.literal("Santuario de la Esmeralda Maestra: nivel " + next + "/7"), true);
                if (level instanceof ServerLevel server) server.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER, pos.getX()+0.5, pos.getY()+1.2, pos.getZ()+0.5, 18, .5, .5, .5, .03);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
    private static void buildSanctuaryUpgrade(Level level, BlockPos core, int levelNumber) {
        Block ringBlock = switch (levelNumber) {
            case 1, 2 -> Blocks.PRISMARINE_BRICKS;
            case 3, 4 -> Blocks.EMERALD_BLOCK;
            case 5, 6 -> Blocks.AMETHYST_BLOCK;
            default -> Blocks.GLOWSTONE;
        };
        int radius = levelNumber < 4 ? 1 : 2;
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            BlockPos pillar = core.relative(direction, radius).above(levelNumber >= 5 ? 1 : 0);
            if (level.isEmptyBlock(pillar)) level.setBlock(pillar, ringBlock.defaultBlockState(), 3);
            if (levelNumber >= 3) {
                BlockPos cap = pillar.above();
                if (level.isEmptyBlock(cap)) level.setBlock(cap, Blocks.SEA_LANTERN.defaultBlockState(), 3);
            }
        }
        if (levelNumber == 7) {
            for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) {
                if (Math.abs(x) + Math.abs(z) != 4) continue;
                BlockPos p = core.offset(x, 0, z);
                if (level.isEmptyBlock(p)) level.setBlock(p, Blocks.POLISHED_DEEPSLATE.defaultBlockState(), 3);
            }
        }
    }
    @Override public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        super.stepOn(level, pos, state, entity);
        if (!level.isClientSide && entity instanceof Player player) {
            int power = state.getValue(LEVEL);
            if (power >= 1) player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, Math.min(2, power / 3), true, false));
            if (power >= 3) player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 0, true, false));
            if (power >= 5) player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 100, 0, true, false));
            if (power >= 7) player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0, true, false));
        }
    }
}
