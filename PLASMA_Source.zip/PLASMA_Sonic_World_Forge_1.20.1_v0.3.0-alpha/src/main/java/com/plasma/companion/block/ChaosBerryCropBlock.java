package com.plasma.companion.block;

import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.CropBlock;

public class ChaosBerryCropBlock extends CropBlock {
    public ChaosBerryCropBlock(Properties properties) { super(properties); }
    @Override protected ItemLike getBaseSeedId() { return PlasmaItems.GREEN_HILL_SEEDS.get(); }
}
