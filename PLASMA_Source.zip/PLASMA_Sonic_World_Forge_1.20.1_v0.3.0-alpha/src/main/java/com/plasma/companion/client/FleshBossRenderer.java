package com.plasma.companion.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.plasma.companion.PlasmaMod;
import com.plasma.companion.entity.FleshBossEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class FleshBossRenderer extends MobRenderer<FleshBossEntity, SonicModel<FleshBossEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(PlasmaMod.MOD_ID, "textures/entity/infected.png");
    public FleshBossRenderer(EntityRendererProvider.Context context) {
        super(context, new SonicModel<>(context.bakeLayer(SonicModel.LAYER)), 0.75F);
    }
    @Override public ResourceLocation getTextureLocation(FleshBossEntity entity) { return TEXTURE; }
    @Override protected void scale(FleshBossEntity entity, PoseStack poseStack, float partialTick) { poseStack.scale(1.7F, 1.7F, 1.7F); }
}
