package com.plasma.companion.entity;

import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class InfectedEntity extends Monster {
    public enum Form { MOBIAN_MUTANT, FLESH_WANDERER, TENTACLE }
    private static final EntityDataAccessor<Integer> FORM = SynchedEntityData.defineId(InfectedEntity.class, EntityDataSerializers.INT);
    public InfectedEntity(EntityType<? extends InfectedEntity> type, Level level) { super(type, level); setForm(this.random.nextInt(3)); }
    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 42.0D).add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 7.0D).add(Attributes.FOLLOW_RANGE, 28.0D).add(Attributes.ARMOR, 3.0D);
    }
    @Override protected void defineSynchedData() { super.defineSynchedData(); this.entityData.define(FORM, 0); }
    public void setForm(int id) {
        int form = Math.floorMod(id, 3);
        this.entityData.set(FORM, form);
        this.setCustomName(Component.literal(switch (Form.values()[form]) {
            case MOBIAN_MUTANT -> "Mobiano mutado"; case FLESH_WANDERER -> "Errante de carne"; case TENTACLE -> "Tentáculo errante";
        }));
    }
    public Form getForm() { return Form.values()[this.entityData.get(FORM)]; }
    @Override protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.12D, false));
        this.goalSelector.addGoal(3, new RandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }
    @Override public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            this.spawnAtLocation(new ItemStack(PlasmaItems.FLESH_FRAGMENT.get(), 1 + this.random.nextInt(3)));
            if (this.random.nextFloat() < 0.22F) this.spawnAtLocation(PlasmaItems.PARASITE_CORE.get());
            if (this.random.nextFloat() < 0.08F) this.spawnAtLocation(PlasmaItems.MANUAL_PAGE.get());
        }
        super.die(source);
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); tag.putInt("InfectedForm", this.entityData.get(FORM)); }
    @Override public void readAdditionalSaveData(CompoundTag tag) { super.readAdditionalSaveData(tag); setForm(tag.getInt("InfectedForm")); }
}
