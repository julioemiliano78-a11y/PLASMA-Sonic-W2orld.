package com.plasma.companion.item;

import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Adds a recovered field-note page to a guide carried by the player. */
public class PlasmaManualPageItem extends Item {
    public PlasmaManualPageItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack page = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(page, true);
        ItemStack guide = ItemStack.EMPTY;
        if (player.getOffhandItem().is(PlasmaItems.FIELD_GUIDE.get())) guide = player.getOffhandItem();
        if (guide.isEmpty()) {
            for (ItemStack candidate : player.getInventory().items) {
                if (candidate.is(PlasmaItems.FIELD_GUIDE.get())) { guide = candidate; break; }
            }
        }
        if (guide.isEmpty()) {
            player.displayClientMessage(Component.literal("Necesitas llevar la Guía de campo de Sonic y PLASMA para archivar esta hoja."), true);
            return InteractionResultHolder.fail(page);
        }
        int unlocked = guide.getOrCreateTag().getInt("UnlockedPages");
        if (unlocked >= 7) {
            player.displayClientMessage(Component.literal("La guía ya contiene todos sus capítulos recuperables."), true);
            return InteractionResultHolder.fail(page);
        }
        guide.getOrCreateTag().putInt("UnlockedPages", unlocked + 1);
        if (!player.getAbilities().instabuild) page.shrink(1);
        player.displayClientMessage(Component.literal("Capítulo " + (unlocked + 1) + "/7" + " añadido a tu guía."), true);
        return InteractionResultHolder.consume(page);
    }
}
