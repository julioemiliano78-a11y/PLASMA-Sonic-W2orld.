package com.plasma.companion.client;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.entity.InfectedEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class InfectedRenderer extends MobRenderer<InfectedEntity, SonicModel<InfectedEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(PlasmaMod.MOD_ID, "textures/entity/infected.png");
    public InfectedRenderer(EntityRendererProvider.Context context) { super(context, new SonicModel<>(context.bakeLayer(SonicModel.LAYER)), 0.45F); }
    @Override public ResourceLocation getTextureLocation(InfectedEntity entity) { return TEXTURE; }
    @Override protected void scale(InfectedEntity entity, PoseStack poseStack, float partialTick) {
        float scale = switch (entity.getForm()) {
            case MOBIAN_MUTANT -> 1.08F;
            case FLESH_WANDERER -> 1.28F;
            case TENTACLE -> 0.82F;
        };
        poseStack.scale(scale, scale, scale);
    }
}
