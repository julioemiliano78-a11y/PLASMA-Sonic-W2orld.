package com.plasma.companion.client;

import com.plasma.companion.entity.PlasmaEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

public class PlasmaModel extends HumanoidModel<PlasmaEntity> {
    public PlasmaModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        PartDefinition head = root.getChild("head");
        PartDefinition body = root.getChild("body");
        PartDefinition rightLeg = root.getChild("right_leg");
        PartDefinition leftLeg = root.getChild("left_leg");

        // Orejas altas y puntiagudas, basadas en la silueta de la hoja de referencia.
        head.addOrReplaceChild("left_ear", CubeListBuilder.create().texOffs(0, 32)
                        .addBox(-1.0F, -12.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offsetAndRotation(3.0F, -5.5F, 0.0F, 0.0F, 0.0F, -0.22F));
        head.addOrReplaceChild("right_ear", CubeListBuilder.create().texOffs(8, 32)
                        .addBox(-1.0F, -12.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offsetAndRotation(-3.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.22F));

        // Tres púas grandes hacia atrás; se mantienen limpias y separadas del torso.
        head.addOrReplaceChild("quill_center", CubeListBuilder.create().texOffs(39, 0)
                        .addBox(-1.2F, -2.0F, 0.0F, 2.4F, 3.2F, 10.0F),
                PartPose.offsetAndRotation(0.0F, -2.0F, 3.2F, -0.12F, 0.0F, 0.0F));
        head.addOrReplaceChild("quill_left", CubeListBuilder.create().texOffs(39, 0)
                        .addBox(-1.0F, -1.5F, 0.0F, 2.0F, 3.0F, 8.0F),
                PartPose.offsetAndRotation(2.4F, -0.2F, 2.6F, -0.2F, 0.10F, -0.22F));
        head.addOrReplaceChild("quill_right", CubeListBuilder.create().texOffs(39, 0)
                        .addBox(-1.0F, -1.5F, 0.0F, 2.0F, 3.0F, 8.0F),
                PartPose.offsetAndRotation(-2.4F, -0.2F, 2.6F, -0.2F, -0.10F, 0.22F));

        // Pequeños mechones laterales para evitar una cabeza humana genérica.
        head.addOrReplaceChild("left_cheek_tuft", CubeListBuilder.create().texOffs(16, 32)
                        .addBox(-2.5F, -0.2F, -1.0F, 3.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(3.0F, 1.0F, 0.0F, 0.0F, 0.1F, 0.25F));
        head.addOrReplaceChild("right_cheek_tuft", CubeListBuilder.create().texOffs(16, 36)
                        .addBox(-0.5F, -0.2F, -1.0F, 3.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(-3.0F, 1.0F, 0.0F, 0.0F, -0.1F, -0.25F));

        // Pecho claro, guantes y botas rojo sangre apagado con remates dorados.
        body.addOrReplaceChild("chest_mark", CubeListBuilder.create().texOffs(24, 32)
                        .addBox(-2.7F, 2.0F, -2.15F, 5.4F, 8.0F, 0.35F), PartPose.ZERO);
        rightLeg.addOrReplaceChild("right_boot", CubeListBuilder.create().texOffs(0, 40)
                        .addBox(-2.1F, 7.0F, -2.5F, 4.2F, 5.0F, 5.0F), PartPose.ZERO);
        leftLeg.addOrReplaceChild("left_boot", CubeListBuilder.create().texOffs(16, 40)
                        .addBox(-2.1F, 7.0F, -2.5F, 4.2F, 5.0F, 5.0F), PartPose.ZERO);
        rightLeg.addOrReplaceChild("right_boot_cuff", CubeListBuilder.create().texOffs(32, 40)
                        .addBox(-2.25F, 6.6F, -2.65F, 4.5F, 1.1F, 5.3F), PartPose.ZERO);
        leftLeg.addOrReplaceChild("left_boot_cuff", CubeListBuilder.create().texOffs(32, 47)
                        .addBox(-2.25F, 6.6F, -2.65F, 4.5F, 1.1F, 5.3F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 64);
    }
}
