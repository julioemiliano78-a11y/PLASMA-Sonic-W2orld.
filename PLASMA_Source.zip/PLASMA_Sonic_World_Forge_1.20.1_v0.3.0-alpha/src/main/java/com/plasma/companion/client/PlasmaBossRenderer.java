package com.plasma.companion.client;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.entity.PlasmaBossEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class PlasmaBossRenderer extends MobRenderer<PlasmaBossEntity, SonicModel<PlasmaBossEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(PlasmaMod.MOD_ID, "textures/entity/plasma_boss.png");
    public PlasmaBossRenderer(EntityRendererProvider.Context context) { super(context, new SonicModel<>(context.bakeLayer(SonicModel.LAYER)), 0.7F); }
    @Override public ResourceLocation getTextureLocation(PlasmaBossEntity entity) { return TEXTURE; }
    @Override protected void scale(PlasmaBossEntity entity, PoseStack poseStack, float partialTick) { poseStack.scale(1.42F, 1.42F, 1.42F); }
}
