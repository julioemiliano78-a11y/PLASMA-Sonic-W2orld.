package com.plasma.companion.registry;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.block.MobianHomeBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class PlasmaBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> TYPES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, PlasmaMod.MOD_ID);
    public static final RegistryObject<BlockEntityType<MobianHomeBlockEntity>> MOBIAN_HOME = TYPES.register("mobian_home",
            () -> BlockEntityType.Builder.of(MobianHomeBlockEntity::new, PlasmaBlocks.MOBIAN_HOME.get()).build(null));
    private PlasmaBlockEntities() { }
}
