package com.plasma.companion.block;

import com.plasma.companion.entity.MobianEntity;
import com.plasma.companion.registry.PlasmaBlockEntities;
import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

public class MobianHomeBlock extends BaseEntityBlock {
    public MobianHomeBlock(Properties properties) { super(properties); }
    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }
    @Nullable @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new MobianHomeBlockEntity(pos, state); }
    @Nullable @Override public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null : createTickerHelper(type, PlasmaBlockEntities.MOBIAN_HOME.get(), MobianHomeBlockEntity::serverTick);
    }
    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity raw = level.getBlockEntity(pos);
        if (!(raw instanceof MobianHomeBlockEntity home)) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        if (held.is(PlasmaItems.CHAOS_SHARD.get())) {
            if (home.upgrade()) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                player.displayClientMessage(Component.literal("Casa ampliada: capacidad " + home.getCapacity() + " residentes."), true);
            } else player.displayClientMessage(Component.literal("La casa ya alcanzó su capacidad máxima."), true);
            return InteractionResult.CONSUME;
        }
        int assigned = 0;
        for (MobianEntity mobian : level.getEntitiesOfClass(MobianEntity.class, new net.minecraft.world.phys.AABB(pos).inflate(20.0D), e -> e.isTame() && e.isOwnedBy(player))) {
            if (assigned >= home.getCapacity()) break;
            mobian.setHomePos(pos);
            assigned++;
        }
        player.displayClientMessage(Component.literal("Hogar asignado a " + assigned + " mobianos. Usa fragmentos del Caos para ampliar la casa."), true);
        return InteractionResult.CONSUME;
    }
}
