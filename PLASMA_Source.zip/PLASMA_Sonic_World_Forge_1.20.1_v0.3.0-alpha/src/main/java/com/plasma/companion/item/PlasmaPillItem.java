package com.plasma.companion.item;

import com.plasma.companion.entity.MobianEntity;
import com.plasma.companion.block.MobianHomeBlockEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** Family mechanic: magical, affectionate bonding and a child entity; no sexual content. */
public class PlasmaPillItem extends Item {
    public PlasmaPillItem(Properties properties) { super(properties); }
    @Override public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof MobianEntity first) || !first.isTame() || !first.isOwnedBy(player)) return InteractionResult.PASS;
        if (player.level().isClientSide) return InteractionResult.SUCCESS;
        List<MobianEntity> partners = player.level().getEntitiesOfClass(MobianEntity.class,
                first.getBoundingBox().inflate(8.0D), m -> m != first && m.isAlive() && m.isTame() && m.isOwnedBy(player) && m.getAge() == 0);
        if (partners.isEmpty()) {
            player.displayClientMessage(Component.literal("La pastilla está activa; acerca otro mobiano adulto adoptado."), true);
            return InteractionResult.CONSUME;
        }
        MobianEntity second = partners.get(0);
        if (first.getHomePos() != null && first.getHomePos().equals(second.getHomePos())
                && player.level().getBlockEntity(first.getHomePos()) instanceof MobianHomeBlockEntity home) {
            long residents = player.level().getEntitiesOfClass(MobianEntity.class, first.getBoundingBox().inflate(32.0D),
                    m -> m.isAlive() && m.isTame() && first.getHomePos().equals(m.getHomePos())).size();
            if (residents >= home.getCapacity()) {
                player.displayClientMessage(Component.literal("La casa ya está llena. Amplíala con un Fragmento del Caos antes de formar otra familia."), true);
                return InteractionResult.CONSUME;
            }
        }
        first.setInLove(player);
        second.setInLove(player);
        if (!player.getAbilities().instabuild) stack.shrink(1);
        if (player.level() instanceof ServerLevel server) {
            for (int i = 0; i < 18; i++) {
                double x = (first.getX() + second.getX()) * 0.5D + (server.random.nextDouble() - 0.5D) * 1.5D;
                double y = Math.max(first.getY(), second.getY()) + 1.0D + server.random.nextDouble();
                double z = (first.getZ() + second.getZ()) * 0.5D + (server.random.nextDouble() - 0.5D) * 1.5D;
                server.sendParticles(ParticleTypes.HEART, x, y, z, 1, 0, 0, 0, 0);
            }
        }
        player.displayClientMessage(Component.literal("¡Vínculo familiar creado! Los dos mobianos podrán tener un descendiente."), true);
        return InteractionResult.CONSUME;
    }
}
