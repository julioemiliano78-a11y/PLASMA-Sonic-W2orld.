package com.plasma.companion.block;

import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;

public class CrystalMillBlock extends Block {
    public static final BooleanProperty HAS_DUST = BooleanProperty.create("has_dust");
    public static final BooleanProperty HAS_WATER = BooleanProperty.create("has_water");
    public CrystalMillBlock(BlockBehaviour.Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(HAS_DUST, false).setValue(HAS_WATER, false));
    }
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HAS_DUST, HAS_WATER);
    }
    @Override public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResult.SUCCESS;
        boolean dust = state.getValue(HAS_DUST), water = state.getValue(HAS_WATER);
        if (held.is(PlasmaItems.POLISHED_DIAMOND.get()) && !dust) {
            if (!player.getAbilities().instabuild) held.shrink(1);
            level.setBlock(pos, state.setValue(HAS_DUST, true), 3);
            player.displayClientMessage(Component.literal("Molino: diamante pulido convertido en polvo."), true);
            return InteractionResult.CONSUME;
        }
        if (held.is(Items.WATER_BUCKET) && dust && !water) {
            if (!player.getAbilities().instabuild) {
                held.shrink(1);
                if (!player.getInventory().add(new ItemStack(Items.BUCKET))) player.drop(new ItemStack(Items.BUCKET), false);
            }
            level.setBlock(pos, state.setValue(HAS_WATER, true), 3);
            player.displayClientMessage(Component.literal("Molino: polvo mezclado con agua."), true);
            return InteractionResult.CONSUME;
        }
        if (held.isEmpty() && dust && water) {
            ItemStack pill = new ItemStack(PlasmaItems.MOBIAN_PILL.get());
            if (!player.getInventory().add(pill)) player.drop(pill, false);
            level.setBlock(pos, state.setValue(HAS_DUST, false).setValue(HAS_WATER, false), 3);
            player.displayClientMessage(Component.literal("Pastilla familiar azul preparada."), true);
            return InteractionResult.CONSUME;
        }
        player.displayClientMessage(Component.literal("Usa 1 diamante pulido, después un cubo de agua y retira la pastilla con la mano vacía."), true);
        return InteractionResult.SUCCESS;
    }
}
