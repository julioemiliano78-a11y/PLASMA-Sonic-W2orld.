package com.plasma.companion.client;

import com.plasma.companion.entity.MobianEntity;
import com.plasma.companion.entity.PlasmaBossEntity;
import com.plasma.companion.entity.InfectedEntity;
import com.plasma.companion.entity.PlasmaEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import com.plasma.companion.PlasmaMod;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.world.entity.Mob;

public class SonicModel<T extends Mob> extends HumanoidModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(PlasmaMod.MOD_ID, "sonic_mobian"), "main");
    public SonicModel(ModelPart root) { super(root); }
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        PartDefinition head = root.getChild("head");
        PartDefinition body = root.getChild("body");
        head.addOrReplaceChild("ear_left", CubeListBuilder.create().texOffs(0, 32).addBox(-1.0F, -12.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offsetAndRotation(3.0F, -5.5F, 0.0F, 0, 0, -0.18F));
        head.addOrReplaceChild("ear_right", CubeListBuilder.create().texOffs(8, 32).addBox(-1.0F, -12.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offsetAndRotation(-3.0F, -5.5F, 0.0F, 0, 0, 0.18F));
        head.addOrReplaceChild("quill_center", CubeListBuilder.create().texOffs(38, 0).addBox(-1.5F, -1.0F, 0.0F, 3.0F, 3.0F, 11.0F),
                PartPose.offsetAndRotation(0.0F, -2.0F, 3.0F, -0.14F, 0.0F, 0.0F));
        head.addOrReplaceChild("quill_left", CubeListBuilder.create().texOffs(38, 0).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.7F, 9.0F),
                PartPose.offsetAndRotation(2.6F, 0.0F, 2.0F, -0.18F, 0.12F, -0.22F));
        head.addOrReplaceChild("quill_right", CubeListBuilder.create().texOffs(38, 0).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.7F, 9.0F),
                PartPose.offsetAndRotation(-2.6F, 0.0F, 2.0F, -0.18F, -0.12F, 0.22F));
        head.addOrReplaceChild("cheek_left", CubeListBuilder.create().texOffs(16, 32).addBox(-2.5F, -0.5F, -1.2F, 3.0F, 2.2F, 2.2F),
                PartPose.offsetAndRotation(3.0F, 1.0F, 0.0F, 0, .1F, .2F));
        head.addOrReplaceChild("cheek_right", CubeListBuilder.create().texOffs(16, 36).addBox(-0.5F, -0.5F, -1.2F, 3.0F, 2.2F, 2.2F),
                PartPose.offsetAndRotation(-3.0F, 1.0F, 0.0F, 0, -.1F, -.2F));
        body.addOrReplaceChild("chest_mark", CubeListBuilder.create().texOffs(24, 32).addBox(-2.7F, 2.0F, -2.15F, 5.4F, 8.0F, 0.35F), PartPose.ZERO);
        body.addOrReplaceChild("crashed_amy_chest", CubeListBuilder.create().texOffs(24, 32)
                .addBox(-3.25F, 1.1F, -2.5F, 6.5F, 5.5F, 0.8F), PartPose.ZERO);
        body.addOrReplaceChild("fox_tail_left", CubeListBuilder.create().texOffs(40, 0).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.5F, 7.0F),
                PartPose.offsetAndRotation(-1.4F, 3.0F, 2.0F, 0.55F, -0.18F, -0.12F));
        body.addOrReplaceChild("fox_tail_right", CubeListBuilder.create().texOffs(40, 0).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.5F, 7.0F),
                PartPose.offsetAndRotation(1.2F, 3.0F, 2.0F, 0.55F, 0.18F, 0.12F));
        body.addOrReplaceChild("bat_wing_left", CubeListBuilder.create().texOffs(48, 16).addBox(0.0F, -3.0F, 0.0F, 5.0F, 7.0F, 1.0F),
                PartPose.offsetAndRotation(2.4F, 1.5F, 0.7F, 0.12F, 0.0F, -0.25F));
        body.addOrReplaceChild("bat_wing_right", CubeListBuilder.create().texOffs(48, 16).addBox(-5.0F, -3.0F, 0.0F, 5.0F, 7.0F, 1.0F),
                PartPose.offsetAndRotation(-2.4F, 1.5F, 0.7F, 0.12F, 0.0F, 0.25F));
        body.addOrReplaceChild("knuckle_spike_left", CubeListBuilder.create().texOffs(56, 32).addBox(-1.0F, -1.0F, -4.5F, 2.0F, 2.0F, 4.0F),
                PartPose.offsetAndRotation(3.0F, 5.5F, 0.0F, 0.0F, 0.0F, -0.2F));
        body.addOrReplaceChild("knuckle_spike_right", CubeListBuilder.create().texOffs(56, 32).addBox(-1.0F, -1.0F, -4.5F, 2.0F, 2.0F, 4.0F),
                PartPose.offsetAndRotation(-3.0F, 5.5F, 0.0F, 0.0F, 0.0F, 0.2F));
        root.getChild("right_leg").addOrReplaceChild("boot_right", CubeListBuilder.create().texOffs(0, 40).addBox(-2.1F, 7.0F, -2.5F, 4.2F, 5.0F, 5.0F), PartPose.ZERO);
        root.getChild("left_leg").addOrReplaceChild("boot_left", CubeListBuilder.create().texOffs(16, 40).addBox(-2.1F, 7.0F, -2.5F, 4.2F, 5.0F, 5.0F), PartPose.ZERO);
        return LayerDefinition.create(mesh, 64, 64);
    }
    @Override public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (entity instanceof PlasmaEntity plasma) {
            switch (plasma.getStage()) {
                case LARVA, COCOON -> { this.rightArm.xRot = -1.2F; this.leftArm.xRot = -1.2F; this.head.xRot = 0.5F; }
                case LEGGED_LARVA -> { this.rightArm.xRot = -0.7F; this.leftArm.xRot = -0.7F; }
                case PUPA -> { this.rightArm.xRot = -1.35F; this.leftArm.xRot = -1.35F; this.head.xRot = 0.25F; }
                case YOUNG -> { this.head.xRot += (float)Math.sin(ageInTicks * 0.16F) * 0.06F; }
                case MANIA -> { this.rightArm.zRot = (float)Math.sin(ageInTicks * 0.28F) * 0.22F; this.leftArm.zRot = -this.rightArm.zRot; }
                default -> { this.rightArm.zRot = (float)Math.sin(ageInTicks * 0.09F) * 0.04F; }
            }
        }
        this.body.getChild("fox_tail_left").visible = false;
        this.body.getChild("fox_tail_right").visible = false;
        this.body.getChild("bat_wing_left").visible = false;
        this.body.getChild("bat_wing_right").visible = false;
        this.body.getChild("knuckle_spike_left").visible = false;
        this.body.getChild("knuckle_spike_right").visible = false;
        this.body.getChild("crashed_amy_chest").visible = false;
        if (entity instanceof MobianEntity mobian) {
            boolean fox = mobian.getVariantType() == MobianEntity.Variant.TAILS || mobian.getVariantType() == MobianEntity.Variant.BIG;
            boolean bat = mobian.getVariantType() == MobianEntity.Variant.ROUGE;
            boolean knuckles = mobian.getVariantType() == MobianEntity.Variant.KNUCKLES;
            this.body.getChild("fox_tail_left").visible = fox;
            this.body.getChild("fox_tail_right").visible = mobian.getVariantType() == MobianEntity.Variant.TAILS;
            this.body.getChild("bat_wing_left").visible = bat;
            this.body.getChild("bat_wing_right").visible = bat;
            this.body.getChild("knuckle_spike_left").visible = knuckles;
            this.body.getChild("knuckle_spike_right").visible = knuckles;
            this.body.getChild("crashed_amy_chest").visible = mobian.getVariantType() == MobianEntity.Variant.AMY_CRASHED;
            if (mobian.getVariantType() == MobianEntity.Variant.AMY_CRASHED) {
                this.head.xRot += 0.03F;
                this.rightArm.zRot = 0.08F;
            }
            if (mobian.isInLove()) {
                // 35 procedural social/family pose variations: lean, nod, turn, wave and embrace silhouettes.
                int pose = mobian.getFamilyAnimationIndex();
                float phase = pose * (float)(Math.PI * 2.0D / 35.0D) + ageInTicks * 0.055F;
                this.body.yRot = (float)Math.sin(phase) * 0.18F;
                this.head.zRot = (float)Math.cos(phase * 1.7F) * 0.13F;
                this.rightArm.xRot = -0.75F + (float)Math.sin(phase * 2.0F) * 0.55F;
                this.leftArm.xRot = -0.75F + (float)Math.cos(phase * 2.0F) * 0.55F;
                this.rightArm.zRot = 0.15F + (float)Math.sin(phase) * 0.28F;
                this.leftArm.zRot = -0.15F - (float)Math.cos(phase) * 0.28F;
            }
        }
        if (entity instanceof InfectedEntity infected) {
            switch (infected.getForm()) {
                case MOBIAN_MUTANT -> { this.body.xRot = 0.12F; this.head.xRot += 0.08F; }
                case FLESH_WANDERER -> { this.body.xRot = 0.22F; this.rightArm.xRot -= 0.25F; this.leftArm.xRot -= 0.25F; }
                case TENTACLE -> { this.rightArm.zRot = -0.9F; this.leftArm.zRot = 0.9F; this.rightArm.xRot = -0.5F; this.leftArm.xRot = -0.5F; }
            }
        }
        if (entity instanceof PlasmaEntity plasma && plasma.isStalker()) {
            this.body.xRot = 0.18F;
            this.head.xRot += 0.18F;
            this.rightArm.xRot = -0.42F;
            this.leftArm.xRot = -0.42F;
        }
        if (entity instanceof PlasmaEntity plasma && plasma.getEatAnimationTicks() > 0) {
            this.rightArm.xRot = -1.15F;
            this.leftArm.xRot = -1.15F;
            this.head.xRot = 0.14F + (float)Math.sin(ageInTicks * 0.35F) * 0.08F;
        }
        if (entity instanceof PlasmaBossEntity) {
            this.head.xRot = headPitch * ((float)Math.PI / 180F) - 0.08F;
            this.rightArm.xRot -= 0.18F;
            this.leftArm.xRot -= 0.18F;
        }
    }
}
