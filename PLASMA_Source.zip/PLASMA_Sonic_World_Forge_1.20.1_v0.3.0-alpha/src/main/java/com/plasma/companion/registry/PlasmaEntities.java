package com.plasma.companion.registry;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.entity.InfectedEntity;
import com.plasma.companion.entity.FleshBossEntity;
import com.plasma.companion.entity.MobianEntity;
import com.plasma.companion.entity.PlasmaBossEntity;
import com.plasma.companion.entity.PlasmaEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class PlasmaEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PlasmaMod.MOD_ID);
    public static final RegistryObject<EntityType<PlasmaEntity>> PLASMA = ENTITY_TYPES.register("plasma", () ->
            EntityType.Builder.<PlasmaEntity>of(PlasmaEntity::new, MobCategory.CREATURE).sized(0.72F, 1.72F).clientTrackingRange(12).build("plasma"));
    public static final RegistryObject<EntityType<MobianEntity>> MOBIAN = ENTITY_TYPES.register("mobian", () ->
            EntityType.Builder.<MobianEntity>of(MobianEntity::new, MobCategory.CREATURE).sized(0.72F, 1.78F).clientTrackingRange(12).build("mobian"));
    public static final RegistryObject<EntityType<InfectedEntity>> INFECTED = ENTITY_TYPES.register("infected", () ->
            EntityType.Builder.<InfectedEntity>of(InfectedEntity::new, MobCategory.MONSTER).sized(0.85F, 1.85F).clientTrackingRange(10).build("infected"));
    public static final RegistryObject<EntityType<PlasmaBossEntity>> PLASMA_BOSS = ENTITY_TYPES.register("plasma_boss", () ->
            EntityType.Builder.<PlasmaBossEntity>of(PlasmaBossEntity::new, MobCategory.MONSTER).sized(1.35F, 2.75F).fireImmune().clientTrackingRange(16).build("plasma_boss"));
    public static final RegistryObject<EntityType<FleshBossEntity>> FLESH_BOSS = ENTITY_TYPES.register("flesh_boss", () ->
            EntityType.Builder.<FleshBossEntity>of(FleshBossEntity::new, MobCategory.MONSTER).sized(1.45F, 2.5F).fireImmune().clientTrackingRange(16).build("flesh_boss"));
    private PlasmaEntities() { }
}
