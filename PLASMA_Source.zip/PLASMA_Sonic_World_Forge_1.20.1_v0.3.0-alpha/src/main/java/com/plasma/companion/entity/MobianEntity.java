package com.plasma.companion.entity;

import com.plasma.companion.registry.PlasmaBlocks;
import com.plasma.companion.registry.PlasmaEntities;
import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.List;

/** Adoptable Sonic-universe mobian. Gender is intentionally not modeled: any two adults can form a family. */
public class MobianEntity extends TamableAnimal {
    public enum Variant {
        SONIC, TAILS, AMY, KNUCKLES, SHADOW, SILVER, BLAZE, CREAM, ROUGE, ESPIO, VECTOR, CHARMY, BIG, AMY_CRASHED;
        public static Variant byId(int id) { return values()[Math.floorMod(id, values().length)]; }
        public String display() {
            return switch (this) {
                case SONIC -> "Sonic"; case TAILS -> "Tails"; case AMY -> "Amy"; case KNUCKLES -> "Knuckles";
                case SHADOW -> "Shadow"; case SILVER -> "Silver"; case BLAZE -> "Blaze"; case CREAM -> "Cream";
                case ROUGE -> "Rouge"; case ESPIO -> "Espio"; case VECTOR -> "Vector"; case CHARMY -> "Charmy";
                case BIG -> "Big"; case AMY_CRASHED -> "Amy (crasheada)";
            };
        }
        public Item preferredFood() {
            return switch (this) {
                case SONIC -> Items.APPLE; case TAILS -> Items.GOLDEN_CARROT; case AMY -> Items.CAKE;
                case KNUCKLES -> Items.BEEF; case SHADOW -> PlasmaItems.CHAOS_BERRY.get(); case SILVER -> Items.GLOW_BERRIES;
                case BLAZE -> Items.BLAZE_POWDER; case CREAM -> Items.CARROT; case ROUGE -> Items.GOLD_INGOT;
                case ESPIO -> Items.SWEET_BERRIES; case VECTOR -> Items.IRON_INGOT; case CHARMY -> Items.HONEYCOMB;
                case BIG -> Items.SALMON; case AMY_CRASHED -> PlasmaItems.CHAOS_BERRY.get();
            };
        }
        public Item missionItem() {
            return switch (this) {
                case SONIC -> PlasmaItems.CHAOS_SHARD.get(); case TAILS -> PlasmaItems.FLESH_FRAGMENT.get();
                case AMY -> PlasmaItems.SCREAMING_BARK.get(); case KNUCKLES -> PlasmaItems.PARASITE_CORE.get();
                case SHADOW -> PlasmaItems.CHAOS_EMERALD.get(); case SILVER -> PlasmaItems.DIAMOND_DUST.get();
                case BLAZE -> Items.FIRE_CHARGE; case CREAM -> Items.CARROT; case ROUGE -> Items.GOLD_INGOT;
                case ESPIO -> Items.STRING; case VECTOR -> Items.IRON_INGOT; case CHARMY -> Items.HONEYCOMB;
                case BIG -> Items.RAW_COD; case AMY_CRASHED -> PlasmaItems.PARASITE_CORE.get();
            };
        }
        public int missionCount() { return switch (this) { case SHADOW, AMY_CRASHED -> 1; case KNUCKLES, AMY -> 3; default -> 5; }; }
        public Item reward() {
            return switch (this) {
                case SONIC -> PlasmaItems.SONIC_BOOTS.get(); case TAILS -> PlasmaItems.TAILS_WRENCH.get();
                case AMY -> PlasmaItems.AMY_HAMMER.get(); case KNUCKLES -> PlasmaItems.KNUCKLES_GAUNTLET.get();
                case SHADOW -> PlasmaItems.SHADOW_SPEAR.get(); case SILVER -> PlasmaItems.SILVER_GLOVE.get();
                case BLAZE -> PlasmaItems.BLAZE_ORB.get(); case AMY_CRASHED -> PlasmaItems.PLASMA_CORE.get();
                default -> PlasmaItems.CHAOS_SHARD.get();
            };
        }
    }

    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(MobianEntity.class, EntityDataSerializers.INT);
    private BlockPos homePos;
    private int questStage = 0;
    private boolean farmingMode = false;

    public MobianEntity(EntityType<? extends MobianEntity> type, Level level) {
        super(type, level);
        this.setVariant(this.random.nextInt(Variant.values().length));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return net.minecraft.world.entity.Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 28.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.29D).add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D).add(Attributes.ARMOR, 2.0D);
    }

    @Override protected void defineSynchedData() { super.defineSynchedData(); this.entityData.define(VARIANT, 0); }
    public void setVariant(int variant) { this.entityData.set(VARIANT, Math.floorMod(variant, Variant.values().length)); this.setCustomName(Component.literal(getVariantType().display())); }
    public Variant getVariantType() { return Variant.byId(this.entityData.get(VARIANT)); }
    public int getVariant() { return this.entityData.get(VARIANT); }
    @Nullable public BlockPos getHomePos() { return homePos; }
    public int getFamilyAnimationIndex() { return Math.floorMod(this.getId() * 7 + this.tickCount / 8, 35); }
    public void setHomePos(BlockPos pos) { homePos = pos == null ? null : pos.immutable(); this.setOrderedToSit(false); }

    @Override protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new BreedGoal(this, 1.0D));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this, 1.15D, 5.0F, 2.0F, false) {
            @Override public boolean canUse() { return isTame() && !isOrderedToSit() && (homePos == null || !level().isNight()) && super.canUse(); }
            @Override public boolean canContinueToUse() { return isTame() && !isOrderedToSit() && (homePos == null || !level().isNight()) && super.canContinueToUse(); }
        });
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this));
    }

    @Override public void tick() {
        super.tick();
        if (this.level().isClientSide || !this.isTame()) return;
        if (!this.level().isNight() && homePos != null && this.isOrderedToSit()) this.setOrderedToSit(false);
        if (this.isOrderedToSit()) return;
        if (this.isInLove() && this.tickCount % 8 == 0 && this.level() instanceof ServerLevel server) {
            server.sendParticles(net.minecraft.core.particles.ParticleTypes.HEART, this.getX(), this.getY() + 1.1D, this.getZ(), 1, .25, .2, .25, .01);
        }
        if (this.tickCount % 80 == 0 && this.getOwner() instanceof Player owner && this.distanceToSqr(owner) < 18.0D) applyCompanionAura(owner);
        if (farmingMode && !this.isBaby() && this.tickCount % 100 == 0 && this.level() instanceof ServerLevel farmLevel) farmNearbyCrops(farmLevel);
        if (this.tickCount % 100 == 0 && homePos == null) {
            BlockPos origin = this.blockPosition();
            BlockPos found = BlockPos.findClosestMatch(origin, 24, 8, p -> this.level().getBlockState(p).is(PlasmaBlocks.MOBIAN_HOME.get())).orElse(null);
            if (found != null) homePos = found.immutable();
        }
        if (homePos != null && this.level().isNight()) {
            if (!this.level().getBlockState(homePos).is(PlasmaBlocks.MOBIAN_HOME.get())) homePos = null;
            else if (this.distanceToSqr(homePos.getX()+0.5D, homePos.getY(), homePos.getZ()+0.5D) > 9.0D) this.getNavigation().moveTo(homePos.getX()+0.5D, homePos.getY(), homePos.getZ()+0.5D, 1.0D);
            else { this.getNavigation().stop(); this.setOrderedToSit(true); }
        }
    }

    private void applyCompanionAura(Player owner) {
        switch (getVariantType()) {
            case SONIC -> { if (owner.isSprinting()) owner.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0, true, false)); }
            case TAILS -> { if (owner.fallDistance > 3.0F) owner.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 80, 0, true, false)); }
            case AMY, CREAM -> { if (owner.getHealth() < owner.getMaxHealth() * 0.45F) owner.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false)); }
            case KNUCKLES -> { if (owner.getLastHurtByMob() != null) owner.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 0, true, false)); }
            case SHADOW -> { if (level().isNight()) owner.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 120, 0, true, false)); }
            case SILVER -> { if (owner.fallDistance > 1.5F) owner.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 60, 0, true, false)); }
            case BLAZE -> { if (owner.isOnFire()) owner.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 60, 0, true, false)); }
            case ROUGE -> { if (owner.getHealth() < owner.getMaxHealth() * 0.3F) owner.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 80, 0, true, false)); }
            default -> { }
        }
    }

    private void farmNearbyCrops(ServerLevel server) {
        BlockPos origin = this.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-4,-1,-4), origin.offset(4,2,4))) {
            BlockState state = server.getBlockState(pos);
            if (state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state)) {
                for (ItemStack drop : Block.getDrops(state, server, pos, server.getBlockEntity(pos), this, ItemStack.EMPTY)) this.spawnAtLocation(drop);
                server.setBlock(pos, crop.defaultBlockState(), 3);
                return;
            }
        }
    }

    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        boolean client = this.level().isClientSide;
        if (!this.isTame() && held.is(getVariantType().preferredFood())) {
            if (!client) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                this.tame(player);
                this.setOrderedToSit(false);
                this.setCustomNameVisible(true);
                this.spawnTamingParticles(true);
                player.displayClientMessage(Component.literal(getVariantType().display() + ": ¡vamos a explorar juntos!"), true);
            }
            return InteractionResult.sidedSuccess(client);
        }
        if (this.isTame() && this.isOwnedBy(player)) {
            if (held.getItem() instanceof HoeItem) {
                if (!client) {
                    farmingMode = !farmingMode;
                    player.displayClientMessage(Component.literal(getVariantType().display() + (farmingMode ? " ayudará a cosechar." : " dejó de cosechar.")), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
            if (held.is(PlasmaItems.MOBIAN_QUEST_SCROLL.get()) && questStage == 0) {
                if (!client) {
                    if (!player.getAbilities().instabuild) held.shrink(1);
                    questStage = 1;
                    player.displayClientMessage(Component.literal(getVariantType().display() + " necesita " + getVariantType().missionCount() + " x " + getVariantType().missionItem().getDescription().getString() + ". Vuelve cuando los tengas."), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
            if (questStage == 1 && held.is(getVariantType().missionItem()) && held.getCount() >= getVariantType().missionCount()) {
                if (!client) {
                    held.shrink(getVariantType().missionCount());
                    ItemStack reward = new ItemStack(getVariantType().reward());
                    if (!player.getInventory().add(reward)) player.drop(reward, false);
                    questStage = 2;
                    player.displayClientMessage(Component.literal(getVariantType().display() + ": ¡misión completada! Recompensa entregada."), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
            if (held.is(PlasmaItems.PLASMA_SYMBIOSIS_FOOD.get()) && getVariantType() == Variant.SONIC) {
                if (!client) {
                    List<PlasmaEntity> plasma = this.level().getEntitiesOfClass(PlasmaEntity.class, this.getBoundingBox().inflate(8.0D), p -> p.getStage() == PlasmaEntity.Stage.YOUNG);
                    if (!plasma.isEmpty()) {
                        plasma.get(0).setStage(PlasmaEntity.Stage.MANIA);
                        if (!player.getAbilities().instabuild) held.shrink(1);
                        player.displayClientMessage(Component.literal("La simbiosis ha comenzado: nace un pequeño PLASMA al estilo Mania."), true);
                    } else player.displayClientMessage(Component.literal("PLASMA joven debe estar cerca de Sonic para iniciar la simbiosis."), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
            if (held.isEmpty() && player.isCrouching()) {
                if (!client) {
                    this.setOrderedToSit(!this.isOrderedToSit());
                    player.displayClientMessage(Component.literal(getVariantType().display() + (this.isOrderedToSit() ? " se quedará aquí." : " te acompañará.")), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
        }
        return super.mobInteract(player, hand);
    }

    @Override public boolean isFood(ItemStack stack) { return false; }

    @Nullable @Override public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
        MobianEntity child = PlasmaEntities.MOBIAN.get().create(level);
        if (child == null) return null;
        int inherited = this.random.nextBoolean() ? this.getVariant() : (mate instanceof MobianEntity other ? other.getVariant() : this.getVariant());
        child.setVariant(inherited);
        if (this.getOwner() instanceof Player owner) child.tame(owner);
        child.setHomePos(this.homePos);
        return child;
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MobianVariant", getVariant());
        tag.putInt("MobianQuestStage", questStage);
        tag.putBoolean("MobianFarmingMode", farmingMode);
        if (homePos != null) { tag.putBoolean("HasMobianHome", true); tag.putInt("HomeX", homePos.getX()); tag.putInt("HomeY", homePos.getY()); tag.putInt("HomeZ", homePos.getZ()); }
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("MobianVariant"));
        questStage = tag.getInt("MobianQuestStage");
        farmingMode = tag.getBoolean("MobianFarmingMode");
        homePos = tag.getBoolean("HasMobianHome") ? new BlockPos(tag.getInt("HomeX"), tag.getInt("HomeY"), tag.getInt("HomeZ")) : null;
    }
}
