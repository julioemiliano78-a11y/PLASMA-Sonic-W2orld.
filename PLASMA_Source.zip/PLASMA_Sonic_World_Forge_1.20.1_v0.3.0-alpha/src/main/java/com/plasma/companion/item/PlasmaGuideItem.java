package com.plasma.companion.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class PlasmaGuideItem extends Item {
    public PlasmaGuideItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide) {
            player.displayClientMessage(Component.literal("§6GUÍA DE CAMPO PLASMA §7— §fUsa las páginas encontradas para descubrir sistemas."), false);
            player.displayClientMessage(Component.literal("§aPLASMA: §fusa la bacteria sobre un animal; coloca el huevo y espera a que nazca."), false);
            player.displayClientMessage(Component.literal("§aCriar: §fprepara la pasta de crecimiento y protege el nido durante la pupa."), false);
            player.displayClientMessage(Component.literal("§aMobianos: §fadopta con su comida favorita; usa la pastilla familiar con dos adultos."), false);
            player.displayClientMessage(Component.literal("§aHogares: §fcoloca una casa mobiana, asigna habitantes y amplíala con Fragmentos del Caos."), false);
            player.displayClientMessage(Component.literal("§aEsmeralda Maestra: §fusa Esmeraldas del Caos para subir el santuario hasta nivel 7."), false);
            player.displayClientMessage(Component.literal("§cDía 500: §fsi no adoptaste a PLASMA, aparecerá su forma hostil."), false);
            int pages = player.getItemInHand(hand).getOrCreateTag().getInt("UnlockedPages");
            player.displayClientMessage(Component.literal("§eCapítulos recuperados: §f" + pages + "/7"), false);
            if (pages >= 1) player.displayClientMessage(Component.literal("§7Capítulo 1: los refugios mobianos aparecen en biomas temáticos."), false);
            if (pages >= 2) player.displayClientMessage(Component.literal("§7Capítulo 2: el polvo de diamante pulido y agua se procesa en el molino."), false);
            if (pages >= 3) player.displayClientMessage(Component.literal("§7Capítulo 3: los fragmentos de carne y núcleos sirven para fabricar equipo."), false);
            if (pages >= 4) player.displayClientMessage(Component.literal("§7Capítulo 4: la pupa atrae zombis; protege el nido hasta que eclosione."), false);
            if (pages >= 5) player.displayClientMessage(Component.literal("§7Capítulo 5: Amy crasheada puede apaciguar a PLASMA hostil."), false);
            if (pages >= 6) player.displayClientMessage(Component.literal("§7Capítulo 6: entrega un Pergamino de misión a un mobiano adoptado."), false);
            if (pages >= 7) player.displayClientMessage(Component.literal("§7Capítulo 7: reúne las Esmeraldas del Caos para mejorar el santuario."), false);
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
