package com.plasma.companion.client;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.registry.PlasmaEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PlasmaMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class PlasmaClientEvents {
    private PlasmaClientEvents() { }
    @SubscribeEvent public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(PlasmaRenderer.LAYER, PlasmaModel::createBodyLayer);
        event.registerLayerDefinition(SonicModel.LAYER, SonicModel::createBodyLayer);
    }
    @SubscribeEvent public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(PlasmaEntities.PLASMA.get(), PlasmaRenderer::new);
        event.registerEntityRenderer(PlasmaEntities.MOBIAN.get(), MobianRenderer::new);
        event.registerEntityRenderer(PlasmaEntities.INFECTED.get(), InfectedRenderer::new);
        event.registerEntityRenderer(PlasmaEntities.PLASMA_BOSS.get(), PlasmaBossRenderer::new);
        event.registerEntityRenderer(PlasmaEntities.FLESH_BOSS.get(), FleshBossRenderer::new);
    }
}
