package com.plasma.companion.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class PlasmaBacteriumItem extends Item {
    public PlasmaBacteriumItem(Properties properties) { super(properties); }
    @Override public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!(target instanceof Animal) || target.getPersistentData().getBoolean("PlasmaHostInfected")) return InteractionResult.PASS;
        if (!player.level().isClientSide) {
            target.getPersistentData().putBoolean("PlasmaHostInfected", true);
            target.getPersistentData().putInt("PlasmaHostTimer", 2400);
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("La bacteria se ha alojado en el huésped. Vigila su comportamiento."), true);
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
