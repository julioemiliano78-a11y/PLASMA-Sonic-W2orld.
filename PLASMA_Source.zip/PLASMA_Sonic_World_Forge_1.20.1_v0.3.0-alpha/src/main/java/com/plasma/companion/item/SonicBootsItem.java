package com.plasma.companion.item;

import com.plasma.companion.registry.PlasmaItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class SonicBootsItem extends Item {
    public SonicBootsItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && !player.getCooldowns().isOnCooldown(this)) {
            if (player.isCrouching()) {
                Vec3 forward = player.getLookAngle().multiply(1.0D, 0.0D, 1.0D).normalize();
                player.setDeltaMovement(player.getDeltaMovement().add(forward.scale(1.75D)).add(0.0D, 0.18D, 0.0D));
                player.hurtMarked = true;
                if (level instanceof ServerLevel server) server.sendParticles(ParticleTypes.SWEEP_ATTACK,
                        player.getX(), player.getY() + 0.8D, player.getZ(), 12, .5, .3, .5, .2);
                player.displayClientMessage(Component.literal("¡SPIN DASH!"), true);
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                player.getCooldowns().addCooldown(this, 80);
            } else {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 240, 2, false, true));
                stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                player.getCooldowns().addCooldown(this, 240);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
    @Override public boolean isValidRepairItem(ItemStack toRepair, ItemStack repair) {
        return repair.is(PlasmaItems.SONIC_QUILL.get()) || super.isValidRepairItem(toRepair, repair);
    }
}
