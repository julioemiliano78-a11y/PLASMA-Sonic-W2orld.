package com.plasma.companion.client;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.entity.PlasmaEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.ModelLayerLocation;

public class PlasmaRenderer extends MobRenderer<PlasmaEntity, PlasmaModel> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            new ResourceLocation(PlasmaMod.MOD_ID, "plasma"), "main");
    private static final ResourceLocation TEXTURE = new ResourceLocation(
            PlasmaMod.MOD_ID, "textures/entity/plasma.png");

    public PlasmaRenderer(EntityRendererProvider.Context context) {
        super(context, new PlasmaModel(context.bakeLayer(LAYER)), 0.42F);
    }

    @Override
    public ResourceLocation getTextureLocation(PlasmaEntity entity) {
        String texture = entity.isStalker() ? "plasma_boss" : switch (entity.getStage()) {
            case LARVA -> "plasma_larva";
            case COCOON -> "plasma_pupa";
            case LEGGED_LARVA -> "plasma_larva_dark";
            case PUPA -> "plasma_pupa";
            case YOUNG -> "plasma_mania";
            case MANIA -> "plasma_mania";
            case ADULT -> "plasma";
        };
        return new ResourceLocation(PlasmaMod.MOD_ID, "textures/entity/" + texture + ".png");
    }

    @Override protected void scale(PlasmaEntity entity, PoseStack poseStack, float partialTick) {
        float scale = switch (entity.getStage()) {
            case LARVA, COCOON -> 0.28F;
            case LEGGED_LARVA -> 0.42F;
            case PUPA -> 0.52F;
            case YOUNG -> 0.68F;
            case MANIA -> 0.82F;
            case ADULT -> 1.0F;
        };
        poseStack.scale(scale, scale, scale);
    }
}
