package com.plasma.companion.client;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.entity.MobianEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;

public class MobianRenderer extends MobRenderer<MobianEntity, SonicModel<MobianEntity>> {
    public MobianRenderer(EntityRendererProvider.Context context) {
        super(context, new SonicModel<>(context.bakeLayer(SonicModel.LAYER)), 0.35F);
    }
    @Override public ResourceLocation getTextureLocation(MobianEntity entity) {
        String texture = switch (entity.getVariantType()) {
            case SONIC -> "sonic"; case TAILS -> "tails"; case AMY -> "amy"; case KNUCKLES -> "knuckles";
            case SHADOW -> "shadow"; case SILVER -> "silver"; case BLAZE -> "blaze"; case CREAM -> "cream";
            case ROUGE -> "rouge"; case ESPIO -> "espio"; case VECTOR -> "vector"; case CHARMY -> "charmy";
            case BIG -> "big"; case AMY_CRASHED -> "amy_crashed";
        };
        return new ResourceLocation(PlasmaMod.MOD_ID, "textures/entity/" + texture + ".png");
    }
    @Override protected void scale(MobianEntity entity, PoseStack poseStack, float partialTick) {
        float scale = entity.isBaby() ? 0.58F : (entity.getVariantType() == MobianEntity.Variant.AMY_CRASHED ? 1.09F : 1.0F);
        poseStack.scale(scale, scale, scale);
    }
}
