package com.plasma.companion;

import com.plasma.companion.entity.InfectedEntity;
import com.plasma.companion.entity.FleshBossEntity;
import com.plasma.companion.entity.MobianEntity;
import com.plasma.companion.entity.PlasmaBossEntity;
import com.plasma.companion.entity.PlasmaEntity;
import com.plasma.companion.registry.PlasmaBlockEntities;
import com.plasma.companion.registry.PlasmaBlocks;
import com.plasma.companion.registry.PlasmaEntities;
import com.plasma.companion.registry.PlasmaItems;
import com.plasma.companion.worldgen.PlasmaRegion;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.registries.RegisterEvent;
import terrablender.api.Regions;

@Mod(PlasmaMod.MOD_ID)
public class PlasmaMod {
    public static final String MOD_ID = "plasma_companion";

    public PlasmaMod() {
        IEventBus modBus = net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus();
        PlasmaEntities.ENTITY_TYPES.register(modBus);
        PlasmaItems.ITEMS.register(modBus);
        PlasmaBlocks.BLOCKS.register(modBus);
        PlasmaBlocks.BLOCK_ITEMS.register(modBus);
        PlasmaBlockEntities.TYPES.register(modBus);
        modBus.addListener(this::registerAttributes);
        modBus.addListener(this::commonSetup);
        modBus.addListener(this::registerSpawnPlacements);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> Regions.register(new PlasmaRegion(new ResourceLocation(MOD_ID, "sonic_overworld"), 8)));
    }

    private void registerSpawnPlacements(SpawnPlacementRegisterEvent event) {
        event.register(PlasmaEntities.PLASMA.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::checkAnimalSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(PlasmaEntities.MOBIAN.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::checkAnimalSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(PlasmaEntities.INFECTED.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
        event.register(PlasmaEntities.FLESH_BOSS.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkMonsterSpawnRules,
                SpawnPlacementRegisterEvent.Operation.REPLACE);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(PlasmaEntities.PLASMA.get(), PlasmaEntity.createAttributes().build());
        event.put(PlasmaEntities.MOBIAN.get(), MobianEntity.createAttributes().build());
        event.put(PlasmaEntities.INFECTED.get(), InfectedEntity.createAttributes().build());
        event.put(PlasmaEntities.PLASMA_BOSS.get(), PlasmaBossEntity.createAttributes().build());
        event.put(PlasmaEntities.FLESH_BOSS.get(), FleshBossEntity.createAttributes().build());
    }
}
