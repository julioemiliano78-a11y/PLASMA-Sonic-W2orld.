package com.plasma.companion.worldgen;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;
import terrablender.api.Region;
import terrablender.api.RegionType;
import java.util.function.Consumer;

/** A climate region containing the Sonic-inspired overworld biomes. */
public final class PlasmaRegion extends Region {
    public PlasmaRegion(ResourceLocation name, int weight) { super(name, RegionType.OVERWORLD, weight); }
    @Override public void addBiomes(Registry<Biome> registry, Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper) {
        Climate.Parameter temp = Climate.Parameter.span(0.12F, 0.82F);
        Climate.Parameter humid = Climate.Parameter.span(0.02F, 0.90F);
        Climate.Parameter continent = Climate.Parameter.span(-0.15F, 0.70F);
        Climate.Parameter erosion = Climate.Parameter.span(-0.70F, 0.35F);
        Climate.Parameter weird = Climate.Parameter.span(-1.0F, 1.0F);
        mapper.accept(Pair.of(Climate.parameters(temp, humid, continent, erosion, Climate.Parameter.point(0.0F), weird, 0.0F), PlasmaBiomes.GREEN_HILL));
        mapper.accept(Pair.of(Climate.parameters(Climate.Parameter.span(0.55F, 1.0F), Climate.Parameter.span(-0.2F, 0.25F),
                Climate.Parameter.span(0.1F, 0.8F), Climate.Parameter.span(-0.45F, 0.15F), Climate.Parameter.span(-0.4F, 0.2F), weird, 0.0F), PlasmaBiomes.EMERALD_COAST));
        mapper.accept(Pair.of(Climate.parameters(Climate.Parameter.span(-0.1F, 0.55F), Climate.Parameter.span(0.2F, 0.8F),
                Climate.Parameter.span(-0.4F, 0.2F), Climate.Parameter.span(-0.2F, 0.5F), Climate.Parameter.span(0.3F, 0.8F), weird, 0.0F), PlasmaBiomes.TWILIGHT_CITY));
        mapper.accept(Pair.of(Climate.parameters(Climate.Parameter.span(0.1F, 0.85F), Climate.Parameter.span(0.6F, 1.0F),
                Climate.Parameter.span(-0.1F, 0.65F), Climate.Parameter.span(-0.55F, 0.15F), Climate.Parameter.span(-0.8F, -0.3F), weird, 0.0F), PlasmaBiomes.CORRUPTED_GREEN_HILL));
    }
}
