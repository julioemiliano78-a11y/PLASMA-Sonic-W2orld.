package com.plasma.companion.registry;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.item.PlasmaBacteriumItem;
import com.plasma.companion.item.CharacterRelicItem;
import com.plasma.companion.item.PlasmaGuideItem;
import com.plasma.companion.item.PlasmaPillItem;
import com.plasma.companion.item.PlasmaManualPageItem;
import com.plasma.companion.item.SonicBootsItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class PlasmaItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PlasmaMod.MOD_ID);

    public static final RegistryObject<Item> PLASMA_CORE = simple("plasma_core", 1);
    public static final RegistryObject<Item> PLASMA_SPAWN_EGG = ITEMS.register("plasma_spawn_egg", () ->
            new ForgeSpawnEggItem(PlasmaEntities.PLASMA, 0x303B3B, 0x8F382D, props(1)));
    public static final RegistryObject<Item> PLASMA_BACTERIUM = ITEMS.register("plasma_bacterium", () -> new PlasmaBacteriumItem(props(16)));
    public static final RegistryObject<Item> PLASMA_GROWTH_MASH = simple("plasma_growth_mash", 16);
    public static final RegistryObject<Item> PLASMA_SYMBIOSIS_FOOD = simple("plasma_symbiosis_food", 16);
    public static final RegistryObject<Item> POLISHED_DIAMOND = simple("polished_diamond", 16);
    public static final RegistryObject<Item> DIAMOND_DUST = simple("diamond_dust", 64);
    public static final RegistryObject<Item> MOBIAN_PILL = ITEMS.register("mobian_family_pill", () -> new PlasmaPillItem(props(8)));
    public static final RegistryObject<Item> CHAOS_BERRY = simple("chaos_berry", 64);
    public static final RegistryObject<Item> GREEN_HILL_SEEDS = simple("green_hill_seeds", 64);
    public static final RegistryObject<Item> GREEN_HILL_BERRY = simple("green_hill_berry", 64);
    public static final RegistryObject<Item> FLESH_FRAGMENT = simple("flesh_fragment", 64);
    public static final RegistryObject<Item> PARASITE_CORE = simple("parasite_core", 16);
    public static final RegistryObject<Item> SCREAMING_BARK = simple("screaming_bark", 64);
    public static final RegistryObject<Item> CHAOS_SHARD = simple("chaos_shard", 64);
    public static final RegistryObject<Item> CHAOS_EMERALD = simple("chaos_emerald", 16);
    public static final RegistryObject<Item> MANUAL_PAGE = ITEMS.register("manual_page", () -> new PlasmaManualPageItem(props(64)));
    public static final RegistryObject<Item> FIELD_GUIDE = ITEMS.register("field_guide", () -> new PlasmaGuideItem(props(1)));
    public static final RegistryObject<Item> MOBIAN_QUEST_SCROLL = simple("mobian_quest_scroll", 16);
    public static final RegistryObject<Item> SONIC_BOOTS = ITEMS.register("sonic_boots", () -> new SonicBootsItem(new Item.Properties().durability(160).tab(CreativeModeTab.TAB_COMBAT)));
    public static final RegistryObject<Item> SONIC_QUILL = simple("sonic_quill", 64);
    public static final RegistryObject<Item> QUILL_BLADE = ITEMS.register("quill_blade", () -> new CharacterRelicItem(props(1), CharacterRelicItem.Power.QUILLS));
    public static final RegistryObject<Item> TAILS_WRENCH = ITEMS.register("tails_wrench", () -> new CharacterRelicItem(props(1), CharacterRelicItem.Power.TAILS_TECH));
    public static final RegistryObject<Item> AMY_HAMMER = ITEMS.register("amy_hammer", () -> new CharacterRelicItem(props(1), CharacterRelicItem.Power.AMY_HEART));
    public static final RegistryObject<Item> KNUCKLES_GAUNTLET = ITEMS.register("knuckles_gauntlet", () -> new CharacterRelicItem(props(1), CharacterRelicItem.Power.KNUCKLES_FORCE));
    public static final RegistryObject<Item> SHADOW_SPEAR = ITEMS.register("shadow_spear", () -> new CharacterRelicItem(props(1), CharacterRelicItem.Power.SHADOW_CHAOS));
    public static final RegistryObject<Item> SILVER_GLOVE = ITEMS.register("silver_glove", () -> new CharacterRelicItem(props(1), CharacterRelicItem.Power.SILVER_PSYCHIC));
    public static final RegistryObject<Item> BLAZE_ORB = ITEMS.register("blaze_orb", () -> new CharacterRelicItem(props(16), CharacterRelicItem.Power.BLAZE_FLARE));

    private static RegistryObject<Item> simple(String id, int stack) {
        return ITEMS.register(id, () -> new Item(props(stack)));
    }

    private static Item.Properties props(int stack) {
        return new Item.Properties().stacksTo(stack).tab(CreativeModeTab.TAB_MISC);
    }

    public static boolean isChaosEmerald(net.minecraft.world.item.ItemStack stack) {
        return stack.is(CHAOS_EMERALD.get());
    }

    private PlasmaItems() { }
}
