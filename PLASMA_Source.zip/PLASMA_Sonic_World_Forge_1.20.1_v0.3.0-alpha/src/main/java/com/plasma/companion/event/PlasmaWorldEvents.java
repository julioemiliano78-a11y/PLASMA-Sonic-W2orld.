package com.plasma.companion.event;

import com.plasma.companion.entity.PlasmaBossEntity;
import com.plasma.companion.entity.PlasmaEntity;
import com.plasma.companion.registry.PlasmaEntities;
import com.plasma.companion.registry.PlasmaBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "plasma_companion", bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PlasmaWorldEvents {
    private PlasmaWorldEvents() { }

    @SubscribeEvent public static void infectedHostTick(LivingEvent.LivingTickEvent event) {
        Entity entity = event.getEntity();
        if (!(entity.level() instanceof ServerLevel) || !(entity instanceof Animal)) return;
        if (!entity.getPersistentData().getBoolean("PlasmaHostInfected")) return;
        int remaining = entity.getPersistentData().getInt("PlasmaHostTimer");
        if (remaining > 0) {
            entity.getPersistentData().putInt("PlasmaHostTimer", remaining - 1);
            if (remaining % 40 == 0 && entity.level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.CRIMSON_SPORE,
                        entity.getX(), entity.getY() + entity.getBbHeight() * 0.72D, entity.getZ(),
                        5, 0.28D, 0.22D, 0.28D, 0.012D);
            }
        } else if (entity.isAlive()) {
            entity.getPersistentData().putBoolean("PlasmaHostBurst", true);
            entity.hurt(entity.damageSources().magic(), 100000.0F);
        }
    }

    @SubscribeEvent public static void infectedHostDeath(LivingDeathEvent event) {
        Entity entity = event.getEntity();
        if (!entity.getPersistentData().getBoolean("PlasmaHostBurst") || !(entity.level() instanceof ServerLevel server)) return;
        ItemStack egg = new ItemStack(PlasmaBlocks.PLASMA_EGG.get().asItem());
        server.addFreshEntity(new ItemEntity(server, entity.getX(), entity.getY() + 0.35D, entity.getZ(), egg));
        server.addFreshEntity(new ItemEntity(server, entity.getX(), entity.getY() + 0.2D, entity.getZ(),
                new ItemStack(com.plasma.companion.registry.PlasmaItems.FLESH_FRAGMENT.get(), 2)));
    }

    @SubscribeEvent public static void playerWorldProgress(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player.level() instanceof ServerLevel level)) return;
        Player player = event.player;
        if (player.tickCount % 200 != 0) return;
        long day = level.getDayTime() / 24000L;
        boolean carriesEgg = false;
        for (ItemStack carried : player.getInventory().items) {
            if (carried.is(PlasmaBlocks.PLASMA_EGG.get().asItem())) { carriesEgg = true; break; }
        }
        if (!carriesEgg) carriesEgg = player.getOffhandItem().is(PlasmaBlocks.PLASMA_EGG.get().asItem());
        if (carriesEgg) player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 260, 0, true, false));
        boolean hasCompanion = player.getPersistentData().getBoolean("PlasmaEverAdopted") || !level.getEntitiesOfClass(PlasmaEntity.class, player.getBoundingBox().inflate(128.0D),
                p -> p.isTame() && p.isOwnedBy(player)).isEmpty();
        if (day >= 500 && !hasCompanion && !player.getPersistentData().getBoolean("PlasmaDay500BossSpawned")) {
            BlockPos spawn = spawnBehind(level, player, 17.0D);
            PlasmaBossEntity boss = PlasmaEntities.PLASMA_BOSS.get().create(level);
            if (boss != null) {
                boss.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D, player.getYRot() + 180.0F, 0.0F);
                level.addFreshEntity(boss);
                player.getPersistentData().putBoolean("PlasmaDay500BossSpawned", true);
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("§4Algo te ha encontrado... PLASMA ya no quiere esconderse."), false);
            }
            return;
        }
        if (day > 1 && day < 30 && !hasCompanion && level.random.nextInt(24) == 0) {
            boolean nearbyStalker = !level.getEntitiesOfClass(PlasmaEntity.class, player.getBoundingBox().inflate(48.0D), PlasmaEntity::isStalker).isEmpty();
            if (!nearbyStalker) {
                BlockPos spawn = spawnBehind(level, player, 9.0D + level.random.nextInt(5));
                PlasmaEntity stalker = PlasmaEntities.PLASMA.get().create(level);
                if (stalker != null) {
                    stalker.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D, player.getYRot() + 180.0F, 0.0F);
                    stalker.setStalker(true);
                    level.addFreshEntity(stalker);
                }
            }
        }
    }

    private static BlockPos spawnBehind(ServerLevel level, Player player, double distance) {
        double angle = Math.toRadians(player.getYRot() + 180.0F) + (level.random.nextDouble() - 0.5D) * 0.8D;
        BlockPos raw = BlockPos.containing(player.getX() + Math.sin(angle) * distance, player.getY(), player.getZ() - Math.cos(angle) * distance);
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, raw);
        if (top.getY() <= level.getMinBuildHeight()) return player.blockPosition().above(1);
        return top;
    }
}
