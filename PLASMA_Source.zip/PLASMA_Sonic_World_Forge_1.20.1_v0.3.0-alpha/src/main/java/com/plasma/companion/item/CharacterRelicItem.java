package com.plasma.companion.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Character-themed relics: short cooldown powers, not just decorative loot. */
public class CharacterRelicItem extends Item {
    public enum Power { QUILLS, TAILS_TECH, AMY_HEART, KNUCKLES_FORCE, SHADOW_CHAOS, SILVER_PSYCHIC, BLAZE_FLARE }
    private final Power power;
    public CharacterRelicItem(Properties properties, Power power) { super(properties); this.power = power; }

    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        switch (power) {
            case QUILLS -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 160, 1));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 160, 0));
            }
            case TAILS_TECH -> {
                player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 300, 0));
                player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 240, 1));
            }
            case AMY_HEART -> {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 1));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 120, 0));
            }
            case KNUCKLES_FORCE -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 1));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 160, 0));
                knockback(level, player, 4.0D, 0.85D);
            }
            case SHADOW_CHAOS -> {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 240, 2));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 180, 1));
            }
            case SILVER_PSYCHIC -> {
                if (level instanceof ServerLevel server) {
                    for (LivingEntity target : server.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(7.0D), e -> e != player && e.isAlive())) {
                        Vec3 push = target.position().subtract(player.position()).normalize().scale(0.75D).add(0, 0.38D, 0);
                        target.setDeltaMovement(target.getDeltaMovement().add(push));
                        target.hurtMarked = true;
                        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
                    }
                    server.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY()+1.0D, player.getZ(), 32, 2.0D, 1.0D, 2.0D, 0.04D);
                }
            }
            case BLAZE_FLARE -> {
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 300, 0));
                if (level instanceof ServerLevel server) server.sendParticles(ParticleTypes.FLAME, player.getX(), player.getY()+1.0D, player.getZ(), 24, 1.0D, .6D, 1.0D, .04D);
            }
        }
        player.getCooldowns().addCooldown(this, power == Power.SILVER_PSYCHIC ? 220 : 180);
        return InteractionResultHolder.consume(stack);
    }

    private static void knockback(Level level, Player player, double radius, double strength) {
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius), e -> e != player && e.isAlive())) {
            Vec3 away = target.position().subtract(player.position()).normalize().scale(strength).add(0, 0.25D, 0);
            target.setDeltaMovement(target.getDeltaMovement().add(away));
            target.hurtMarked = true;
        }
    }
}
