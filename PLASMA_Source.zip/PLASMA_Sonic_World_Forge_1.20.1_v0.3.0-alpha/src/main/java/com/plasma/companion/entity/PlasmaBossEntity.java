package com.plasma.companion.entity;

import com.plasma.companion.registry.PlasmaEntities;
import com.plasma.companion.registry.PlasmaItems;
import com.plasma.companion.registry.PlasmaBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

public class PlasmaBossEntity extends Monster {
    private boolean pacified = false;
    private int summonCooldown = 0;
    public PlasmaBossEntity(EntityType<? extends PlasmaBossEntity> type, Level level) { super(type, level); this.setCustomName(Component.literal("PLASMA | La Plaga")); this.setCustomNameVisible(true); }
    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 2000.0D).add(Attributes.MOVEMENT_SPEED, 0.36D)
                .add(Attributes.ATTACK_DAMAGE, 28.0D).add(Attributes.ARMOR, 18.0D).add(Attributes.FOLLOW_RANGE, 72.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.95D);
    }
    @Override protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.22D, true) { @Override public boolean canUse() { return !pacified && super.canUse(); } });
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, p -> !pacified));
    }
    @Override public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        if (summonCooldown > 0) summonCooldown--;
        if (this.tickCount % 20 == 0) {
            MobianEntity amy = this.level().getEntitiesOfClass(MobianEntity.class, this.getBoundingBox().inflate(12.0D),
                    m -> m.getVariantType() == MobianEntity.Variant.AMY_CRASHED && m.isTame()).stream().findFirst().orElse(null);
            if (amy != null && !pacified) {
                pacified = true;
                this.setTarget(null);
                this.setCustomName(Component.literal("PLASMA | Reconocido"));
                this.level().broadcastEntityEvent(this, (byte) 7);
                if (this.level() instanceof ServerLevel server) server.sendParticles(net.minecraft.core.particles.ParticleTypes.HEART,
                        getX(), getY() + 2.3D, getZ(), 12, 1.0D, 0.7D, 1.0D, 0.02D);
            }
        }
        if (!pacified && summonCooldown <= 0 && this.getTarget() != null && this.level() instanceof ServerLevel server) {
            for (int i = 0; i < 2; i++) {
                InfectedEntity minion = PlasmaEntities.INFECTED.get().create(server);
                if (minion != null) {
                    double angle = this.random.nextDouble() * Math.PI * 2.0D;
                    minion.moveTo(getX() + Math.cos(angle) * 3.0D, getY(), getZ() + Math.sin(angle) * 3.0D, 0, 0);
                    server.addFreshEntity(minion);
                }
            }
            summonCooldown = 240;
        }
    }
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (pacified && !this.level().isClientSide) {
            PlasmaEntity companion = PlasmaEntities.PLASMA.get().create(this.level());
            if (companion != null) {
                companion.moveTo(this.getX(), this.getY(), this.getZ(), this.getYRot(), 0);
                companion.setStage(PlasmaEntity.Stage.ADULT);
                companion.tame(player);
                player.getPersistentData().putBoolean("PlasmaEverAdopted", true);
                companion.setCustomName(Component.literal("PLASMA"));
                this.level().addFreshEntity(companion);
                this.discard();
                player.displayClientMessage(Component.literal("Amy consiguió tranquilizar a PLASMA. Ahora es tu compañero."), true);
            }
            return InteractionResult.CONSUME;
        }
        return super.mobInteract(player, hand);
    }
    @Override public void die(DamageSource source) {
        if (!this.level().isClientSide) {
            this.spawnAtLocation(new ItemStack(PlasmaBlocks.PLASMA_EGG.get().asItem()));
            this.spawnAtLocation(new ItemStack(PlasmaItems.SONIC_BOOTS.get()));
            this.spawnAtLocation(new ItemStack(PlasmaItems.SONIC_QUILL.get(), 3 + this.random.nextInt(4)));
            this.spawnAtLocation(new ItemStack(PlasmaItems.CHAOS_SHARD.get(), 8 + this.random.nextInt(9)));
        }
        super.die(source);
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) { super.addAdditionalSaveData(tag); tag.putBoolean("Pacified", pacified); tag.putInt("SummonCooldown", summonCooldown); }
    @Override public void readAdditionalSaveData(CompoundTag tag) { super.readAdditionalSaveData(tag); pacified = tag.getBoolean("Pacified"); summonCooldown = tag.getInt("SummonCooldown"); }
}
