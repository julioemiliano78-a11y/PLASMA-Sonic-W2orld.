package com.plasma.companion.registry;

import com.plasma.companion.PlasmaMod;
import com.plasma.companion.block.ChaosBerryCropBlock;
import com.plasma.companion.block.CrystalMillBlock;
import com.plasma.companion.block.MobianHomeBlock;
import com.plasma.companion.block.PlasmaEggBlock;
import com.plasma.companion.block.PlasmaNestBlock;
import com.plasma.companion.block.ScreamingTreeBlock;
import com.plasma.companion.block.MasterEmeraldBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class PlasmaBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, PlasmaMod.MOD_ID);
    public static final DeferredRegister<Item> BLOCK_ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, PlasmaMod.MOD_ID);

    public static final RegistryObject<Block> PLASMA_EGG = register("plasma_egg", () -> new PlasmaEggBlock(
            BlockBehaviour.Properties.copy(Blocks.HONEY_BLOCK).strength(1.4F, 8.0F).noOcclusion().randomTicks()));
    public static final RegistryObject<Block> CRYSTAL_MILL = register("crystal_mill", () -> new CrystalMillBlock(
            BlockBehaviour.Properties.copy(Blocks.STONE).strength(2.5F).sound(SoundType.STONE)));
    public static final RegistryObject<Block> MOBIAN_HOME = register("mobian_home", () -> new MobianHomeBlock(
            BlockBehaviour.Properties.copy(Blocks.OAK_PLANKS).strength(2.0F).sound(SoundType.WOOD)));
    public static final RegistryObject<Block> PLASMA_NEST = register("plasma_nest", () -> new PlasmaNestBlock(
            BlockBehaviour.Properties.copy(Blocks.HAY_BLOCK).strength(0.8F).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> MASTER_EMERALD = register("master_emerald_sanctuary", () -> new MasterEmeraldBlock(
            BlockBehaviour.Properties.copy(Blocks.EMERALD_BLOCK).strength(5.0F).lightLevel(s -> 5 + s.getValue(MasterEmeraldBlock.LEVEL))));
    public static final RegistryObject<Block> SCREAMING_HEARTWOOD = register("screaming_heartwood", () -> new ScreamingTreeBlock(
            BlockBehaviour.Properties.copy(Blocks.DARK_OAK_LOG).strength(2.2F).sound(SoundType.WOOD)));
    public static final RegistryObject<Block> CHAOS_BERRY_CROP = register("chaos_berry_crop", () -> new ChaosBerryCropBlock(
            BlockBehaviour.Properties.copy(Blocks.WHEAT).noCollission().randomTicks().instabreak().sound(SoundType.CROP)));
    public static final RegistryObject<Block> CHAOS_CRYSTAL_ORE = register("chaos_crystal_ore", () -> new Block(
            BlockBehaviour.Properties.copy(Blocks.DIAMOND_ORE).strength(4.0F).lightLevel(s -> 2)));
    public static final RegistryObject<Block> LIVING_FLESH_ORE = register("living_flesh_ore", () -> new Block(
            BlockBehaviour.Properties.copy(Blocks.REDSTONE_ORE).strength(3.0F).sound(SoundType.SLIME_BLOCK)));

    private static RegistryObject<Block> register(String id, java.util.function.Supplier<Block> factory) {
        RegistryObject<Block> block = BLOCKS.register(id, factory);
        BLOCK_ITEMS.register(id, () -> new BlockItem(block.get(), new Item.Properties().tab(CreativeModeTab.TAB_BUILDING_BLOCKS)));
        return block;
    }

    private PlasmaBlocks() { }
}
