package com.plasma.companion.worldgen;

import com.plasma.companion.PlasmaMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;

public final class PlasmaBiomes {
    public static final ResourceKey<Biome> GREEN_HILL = key("green_hill");
    public static final ResourceKey<Biome> EMERALD_COAST = key("emerald_coast");
    public static final ResourceKey<Biome> TWILIGHT_CITY = key("twilight_city");
    public static final ResourceKey<Biome> CORRUPTED_GREEN_HILL = key("corrupted_green_hill");
    private static ResourceKey<Biome> key(String id) { return ResourceKey.create(Registries.BIOME, new ResourceLocation(PlasmaMod.MOD_ID, id)); }
    private PlasmaBiomes() { }
}
