# PLASMA: Sonic World — Forge 1.20.1 (0.3.0-alpha)

Proyecto fuente de un mod de supervivencia y exploración inspirado en el universo Sonic, con PLASMA como personaje central. Esta entrega reúne los sistemas principales descritos hasta ahora: biomas y estructuras temáticas, mobianos adoptables, infección parasitaria, familias y hogares, progresión del huevo de PLASMA, jefe del día 500, objetos, cultivos, guía de descubrimientos y tareas para PLASMA.

**Estado:** versión de desarrollo avanzada, no una compilación final certificada. Los JSON y las plantillas NBT se validan localmente; este entorno no tiene JDK 17, Gradle ni acceso a las dependencias de Forge, por lo que no se pudo compilar ni abrir el mod en Minecraft. Considera esta versión una alfa que necesita pruebas dentro del juego antes de usarla en un mundo importante.

## 1. Versiones necesarias

- Minecraft **Java 1.20.1**.
- Minecraft Forge **47.4.29**.
- Java Development Kit **17** (64 bits), para compilar.
- **TerraBlender Forge 1.20.1 — 3.0.1.11**, dependencia obligatoria para los biomas.

Descarga TerraBlender 3.0.1.11: https://modrinth.com/mod/terrablender/version/IfcgopfA

El JAR de TerraBlender y el JAR compilado de PLASMA deben estar juntos en la carpeta `mods` de la misma instalación de Forge.

## 2. Mundo Sonic

El mod añade cuatro biomas personalizados al Overworld:

- **Green Hill:** colinas verdes y vegetación densa, con flores y árboles.
- **Costa Esmeralda:** litoral cálido con vegetación y recursos temáticos.
- **Ciudad Crepuscular:** bioma de estética urbana y tonos de atardecer.
- **Green Hill Infectado:** variante corrompida con recursos y criaturas parasitarias.

También incluye seis estructuras listas para generación:

1. **Aldea Green Hill:** casas, mercado, senderos, fuente, aldeanos y cofres.
2. **Ciudad derrumbada:** ruinas, muros y torres rotas, con loot de exploración.
3. **Mina pequeña:** túneles, soportes, raíles, telarañas y cofre.
4. **Dungeon de carne:** estructura hostil con spawner del Guardián Mutante y cofres.
5. **Refugio mobiano:** refugio temático con botín.
6. **Santuario de la Esmeralda Maestra:** estructura especial con cofre y bloque de santuario mejorable.

Los biomas y estructuras solo aparecen en chunks nuevos. Para encontrarlos, crea un mundo nuevo o explora terreno que aún no se haya generado. Las distancias y frecuencias finales necesitan ajuste tras las primeras pruebas reales.

## 3. Mobianos adoptables

La entidad mobiana tiene 14 variantes: **Sonic, Tails, Amy, Knuckles, Shadow, Silver, Blaze, Cream, Rouge, Espio, Vector, Charmy, Big y Amy crasheada**. Las variantes comparten una base de modelo humanoide de estilo Minecraft con texturas, accesorios y habilidades particulares; no son todavía modelos independientes de alta complejidad.

Los mobianos aparecen con más posibilidades en los biomas etiquetados como biomas Sonic. Cada variante acepta un alimento preferido distinto. Al dar el alimento correcto, el personaje queda domesticado y sigue al jugador.

### Misiones y recompensas

Entrega un **Pergamino de misión mobiana** a un mobiano adoptado. Te indicará un objeto y una cantidad. Devuelve los materiales solicitados para cobrar la recompensa de su personaje. Las recompensas incluyen botas de Sonic, herramientas/armas de personaje, reliquias y fragmentos del Caos.

### Familia y descendientes

La pastilla azul es un mecanismo mágico de vínculo familiar, sin contenido sexual. Funciona con dos mobianos adultos adoptados por el mismo jugador, sin exigir una combinación de géneros. La entidad hija hereda la variante de uno de sus padres y queda vinculada a su propietario. Se generaron **35 variaciones procedurales de poses sociales/afectuosas** durante la animación del vínculo; no son 35 secuencias de captura de movimiento independientes.

**Preparar la pastilla:**

1. Fabrica un **Diamante pulido** con un diamante y cuarzo.
2. Fabrica un **Molino de cristales** con piedra, lingotes de hierro y una piedra de afilar.
3. Usa el diamante pulido en el molino para convertirlo en polvo.
4. Usa un cubo de agua para mezclar el polvo.
5. Haz clic derecho con la mano vacía para recoger la pastilla familiar azul.
6. Usa la pastilla sobre uno de los dos mobianos adultos; el compañero compatible debe estar a menos de 8 bloques.

La casa mobiana comienza con capacidad para dos residentes y se puede ampliar gastando **Fragmentos del Caos** hasta un máximo de doce. Haz clic derecho en la casa para asignar mobianos cercanos adoptados; hazlo con un Fragmento del Caos en la mano para mejorarla. Los habitantes buscan el hogar al anochecer y se sientan cerca. Los corazones sobre la casa indican que tiene residentes vinculados cerca; en esta alfa el indicador usa un radio alrededor del bloque de hogar, no comprueba habitaciones interiores.

## 4. PLASMA: infección, huevo y crecimiento

PLASMA no aparece como enemigo común al llegar al día 500. Primero existe una ruta de descubrimiento y crianza:

1. Usa la **Bacteria de PLASMA** sobre un animal vanilla. El animal queda infectado durante un tiempo y aparecen partículas parasitarias.
2. Cuando termina el proceso, el huésped muere y deja sus drops habituales, un huevo parasitario y fragmentos de carne.
3. Coloca el huevo en el suelo. Después de aproximadamente **60 segundos** aparece la larva pálida.
4. Fabrica **Pasta de crecimiento** con huevo de gallina, cubo de leche y azúcar. Dásela a la larva para que forme una crisálida.
5. La crisálida necesita cerca de **60 segundos acumulados de día con cielo visible** para convertirse en larva oscura con patas.
6. Fabrica y coloca un **Nido de PLASMA**. Dale otra Pasta de crecimiento a la larva oscura cerca del nido para iniciar la etapa de pupa.
7. Durante la pupa aparecen oleadas de zombis; protege el nido durante aproximadamente **2 minutos**. Después nace PLASMA joven.
8. Acerca PLASMA joven a Sonic y dale a Sonic la **Comida de simbiosis**. Comienza la transición a la forma pequeña inspirada en Sonic Mania.
9. La etapa Mania tarda aproximadamente **10 minutos** en llegar a PLASMA adulto.

Puedes domesticar a PLASMA con un **Fragmento oscuro** o una **Baya del Caos**. Los estadios pequeños no tienen la defensa de combate del adulto. El adulto puede defender al jugador y hacer trabajos sencillos; no necesita comida para sobrevivir, pero acepta comida, se sienta en una animación de comer y recupera salud.

La forma visual se basa en tu hoja de referencia y tu imagen de colores: pelaje gris carbón con matiz teal, hocico rojo apagado, zona ocular oscura con pequeños detalles rojos, púas largas y detalles oscuros/rojizos. La ropa de la imagen de referencia no está incluida en el diseño.

### Acecho durante los primeros días

Entre los días 2 y 29 puede aparecer brevemente como presencia de terror detrás del jugador. Si consigue que lo veas, usa un sonido de susto y un efecto breve de oscuridad, y desaparece. Si permanece en el mundo el tiempo suficiente, puede dejar Fragmentos del Caos cerca de tu punto de reaparición o del jugador. Tiene navegación terrestre, puede abrir puertas y superar pequeños desniveles; **no** atraviesa paredes, rompe bloques ni tiene escalada libre por superficies verticales.

### Jefe del día 500

Si el jugador llega al día 500 sin haber adoptado a PLASMA, se activa **PLASMA: La Plaga**, con **2000 puntos de vida**, gran fuerza, armadura y capacidad para invocar infectados. Si ya adoptaste a PLASMA, este jefe no debería activarse para ese jugador.

La Amy crasheada debe estar domesticada y cerca del jefe para activar la secuencia de apaciguamiento. Después podrás interactuar con él para recibir a PLASMA adulto como aliado. Si derrotas al jefe, deja un huevo de PLASMA, Botas de Sonic, Púas de Sonic y Fragmentos del Caos.

## 5. Infección y enemigos

Se incluyen tres formas de entidad hostil infectada:

- **Mobiano mutante:** cuerpo mobiano alterado por el parásito.
- **Errante de carne:** criatura humanoide amorfa.
- **Tentáculo errante:** variante agresiva con movimientos y postura distintos.

También hay un **Guardián del Núcleo** como jefe para la dungeon de carne. Al derrotarlo puede dejar una Esmeralda del Caos, núcleos parasitarios, fragmentos de carne y páginas de la guía.

Los **Árboles Gritones** tienen una posibilidad de emitir un rugido y provocar náuseas al pisarlos; su madera/corteza se aprovecha como material. La infección tiene partículas y menas propias. Esta versión usa variantes hostiles originales del mod y zombis vanilla durante la defensa de la pupa; todavía no incluye docenas de criaturas individuales ni animaciones de terror cinematográficas.

## 6. Materiales, armas, poderes y guía

Entre los recursos y objetos incluidos están:

- Fragmento del Caos, Esmeralda del Caos y Núcleo parasitario.
- Fragmento de carne, Corteza gritona, Polvo de diamante y Diamante pulido.
- Baya de Green Hill, Baya del Caos y sus semillas/cultivo.
- Botas de Sonic (reparables con Púas de Sonic en un yunque), Hoja de púas, Llave de Tails, Martillo de Amy, Guantelete de Knuckles, Lanza de Shadow, Guante psíquico de Silver y Orbe de Blaze.
- Reliquias con efectos de velocidad, tecnología, fuerza, caos, telequinesis y fuego.

El **Santuario de la Esmeralda Maestra** tiene hasta siete niveles de mejora. Usa Esmeraldas del Caos para avanzar y obtener efectos progresivos. Las mejoras también añaden una decoración de bloques alrededor del santuario.

La **Guía de campo de Sonic y PLASMA** empieza con instrucciones esenciales. Encuentra páginas en cofres y botín de enemigos; usa cada página mientras llevas la guía para desbloquear nuevos capítulos.

## 7. Órdenes y trabajos de PLASMA adulto

Primero adopta a PLASMA. Después entrégale el objeto asociado al trabajo y materiales para su mochila de nueve espacios. Haz clic derecho con mano vacía para abrir la mochila; agáchate y haz clic derecho con mano vacía para alternar órdenes de seguir, quedarse y proteger zona.

| Objeto que le entregas | Trabajo | Alcance real de esta alfa |
|---|---|---|
| Azada y semillas/plantables | Agricultura | Labra terreno, planta trigo/zanahoria/patata/remolacha y cosecha cultivos maduros en una zona corta. |
| Cubo vacío | Ordeñar | Busca vacas adultas próximas y convierte el cubo en cubo de leche. |
| Pico | Minería | Extrae menas expuestas cercanas dentro de un área limitada; no excava galerías largas ni busca minerales a gran profundidad. |
| Bloques de construcción | Construcción | Coloca una cabaña muy sencilla de bloques aportados; no genera una casa decorada completa con interiores. |

PLASMA también recoge objetos que pasan muy cerca. Estos trabajos son rutinas acotadas, no un agente autónomo que comprenda órdenes escritas o planifique una construcción compleja.

## 8. Comandos de prueba

En creativo o con permisos de operador:

```mcfunction
/give @p plasma_companion:plasma_bacterium
/give @p plasma_companion:plasma_spawn_egg
/give @p plasma_companion:plasma_core
/give @p plasma_companion:field_guide
/give @p plasma_companion:mobian_home
/locate biome plasma_companion:green_hill
/locate structure plasma_companion:green_hill_village
/locate structure plasma_companion:ruined_city
/locate structure plasma_companion:small_mine
/locate structure plasma_companion:flesh_dungeon
/locate structure plasma_companion:mobian_shelter
/locate structure plasma_companion:master_sanctuary
```

Para pruebas directas de entidades:

```mcfunction
/summon plasma_companion:mobian
/summon plasma_companion:infected
/summon plasma_companion:flesh_boss
/summon plasma_companion:plasma_boss
```

Las estructuras también se pueden colocar en ubicaciones de prueba con `/place structure plasma_companion:<id>` si la estructura está registrada correctamente en la instancia.

## 9. Compilar e instalar en Windows

1. Instala Minecraft Java 1.20.1 con Forge 47.4.29.
2. Descarga e instala TerraBlender 3.0.1.11 para Forge 1.20.1.
3. Instala un JDK 17 de 64 bits y asegúrate de que `java -version` indique versión 17. Si Windows no encuentra Java, configura `JAVA_HOME` al directorio del JDK 17 y añade `%JAVA_HOME%\bin` al `PATH`.
4. Descomprime la carpeta del proyecto.
5. Ejecuta `validate_assets.bat` para revisar los JSON, las texturas y las estructuras NBT antes de compilar. Esta revisión no comprueba el código Java.
6. Haz doble clic en `build.bat`. La primera ejecución descarga Gradle 8.8 y las dependencias del proyecto, por lo que necesita conexión a Internet.
7. Si la compilación termina correctamente, el JAR aparecerá en `build\libs\plasma_companion-0.3.0-alpha.jar`.
8. Copia ese JAR y el JAR de TerraBlender a `%appdata%\.minecraft\mods` de la misma instalación de Forge.
9. Crea un mundo nuevo de prueba, preferiblemente separado de tus partidas principales. Para iniciar el cliente de desarrollo directamente desde el proyecto, usa `runClient.bat`.

## 10. Estado real y límites conocidos

- La validación local comprueba sintaxis JSON, texturas referenciadas por modelos, referencias de blockstates, seis archivos NBT, paletas, coordenadas, tablas de botín y el spawner del jefe de carne.
- **No se pudo ejecutar Gradle ni compilar el código Java en este entorno**, porque aquí no están disponibles JDK 17 ni Gradle y no se pueden descargar las dependencias. Tampoco se pudo abrir Minecraft para probar generación, pathfinding, sincronización de animaciones, combate o guardado/carga.
- El modelo mobiano comparte una base humanoide de estilo Minecraft con variantes, accesorios y texturas. No es todavía un modelo de alta resolución independiente para cada personaje.
- La versión incluye 14 variantes mobianas, no la totalidad del reparto de Sonic.
- Las 35 variaciones de interacción familiar son poses procedurales, no 35 animaciones artesanales completas.
- El indicador de corazón de la casa comprueba residentes en un radio alrededor del hogar, no si cada uno está dentro de una habitación.
- La aparición de biomas/estructuras y sus frecuencias precisan calibración dentro de un mundo real. Los nuevos recursos solo se generan en chunks nuevos.
- Los ataques, la IA de trabajo y los comportamientos de acecho son una primera implementación funcional prevista para pruebas; necesitan balance y depuración en Minecraft.

Incluye las dos imágenes de referencia compartidas en `reference/`. El archivo `tools/validate_assets.py` permite volver a revisar los recursos locales antes de compilar.
