"""Validate PLASMA resource JSON, model references and NBT structures without third-party packages."""
from __future__ import annotations

import gzip
import json
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESOURCES = ROOT / "src" / "main" / "resources"
MOD_ID = "plasma_companion"


class NBTReader:
    def __init__(self, data: bytes):
        self.data = data
        self.offset = 0

    def take(self, count: int) -> bytes:
        chunk = self.data[self.offset:self.offset + count]
        self.offset += count
        if len(chunk) != count:
            raise ValueError("NBT incompleto")
        return chunk

    def u8(self) -> int: return self.take(1)[0]
    def i8(self) -> int: return struct.unpack(">b", self.take(1))[0]
    def i16(self) -> int: return struct.unpack(">h", self.take(2))[0]
    def i32(self) -> int: return struct.unpack(">i", self.take(4))[0]
    def i64(self) -> int: return struct.unpack(">q", self.take(8))[0]
    def f32(self) -> float: return struct.unpack(">f", self.take(4))[0]
    def f64(self) -> float: return struct.unpack(">d", self.take(8))[0]

    def string(self) -> str:
        length = struct.unpack(">H", self.take(2))[0]
        return self.take(length).decode("utf-8")

    def payload(self, tag_type: int):
        if tag_type == 1: return self.i8()
        if tag_type == 2: return self.i16()
        if tag_type == 3: return self.i32()
        if tag_type == 4: return self.i64()
        if tag_type == 5: return self.f32()
        if tag_type == 6: return self.f64()
        if tag_type == 7:
            length = self.i32()
            if length < 0: raise ValueError("Longitud negativa en ByteArray")
            return self.take(length)
        if tag_type == 8: return self.string()
        if tag_type == 9:
            element_type = self.u8()
            length = self.i32()
            if length < 0: raise ValueError("Longitud negativa en List")
            return [self.payload(element_type) for _ in range(length)]
        if tag_type == 10:
            result = {}
            while True:
                child_type = self.u8()
                if child_type == 0: break
                child_name = self.string()
                result[child_name] = self.payload(child_type)
            return result
        if tag_type == 11:
            length = self.i32()
            if length < 0: raise ValueError("Longitud negativa en IntArray")
            return [self.i32() for _ in range(length)]
        if tag_type == 12:
            length = self.i32()
            if length < 0: raise ValueError("Longitud negativa en LongArray")
            return [self.i64() for _ in range(length)]
        raise ValueError(f"Tipo NBT desconocido: {tag_type}")


def read_nbt(path: Path) -> dict:
    reader = NBTReader(gzip.decompress(path.read_bytes()))
    if reader.u8() != 10:
        raise ValueError("La raíz de la plantilla no es un Compound")
    reader.string()
    root = reader.payload(10)
    if reader.offset != len(reader.data):
        raise ValueError("Hay bytes sobrantes al final del NBT")
    return root


def resource_path(namespace: str, category: str, path: str) -> Path:
    return RESOURCES / "assets" / namespace / category / (path + ".json")


def main() -> int:
    problems: list[str] = []
    json_files = sorted(RESOURCES.rglob("*.json"))
    parsed: dict[Path, object] = {}
    for path in json_files:
        try:
            parsed[path] = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            problems.append(f"JSON inválido: {path.relative_to(ROOT)}: {exc}")

    # Model texture and parent references: catch missing resources before the game loads them.
    model_files = sorted((RESOURCES / "assets" / MOD_ID / "models").rglob("*.json"))
    for path in model_files:
        model = parsed.get(path)
        if not isinstance(model, dict):
            continue
        parent = model.get("parent")
        if isinstance(parent, str) and ":" in parent:
            namespace, model_id = parent.split(":", 1)
            if namespace == MOD_ID:
                parent_path = resource_path(namespace, "models", model_id)
                if not parent_path.exists():
                    problems.append(f"Modelo padre ausente: {path.relative_to(ROOT)} -> {parent}")
        textures = model.get("textures", {})
        if isinstance(textures, dict):
            for key, value in textures.items():
                if not isinstance(value, str) or value.startswith("#"):
                    continue
                namespace, texture_id = value.split(":", 1) if ":" in value else (MOD_ID, value)
                texture_path = RESOURCES / "assets" / namespace / "textures" / (texture_id + ".png")
                if not texture_path.exists():
                    problems.append(f"Textura ausente: {path.relative_to(ROOT)} ({key} -> {value})")

    # Hard-coded renderer texture paths in Java must also exist.
    for java_file in sorted((ROOT / "src" / "main" / "java").rglob("*.java")):
        source = java_file.read_text(encoding="utf-8")
        for texture_id in re.findall(r"textures/entity/([a-z0-9_]+)\.png", source):
            texture_path = RESOURCES / "assets" / MOD_ID / "textures" / "entity" / (texture_id + ".png")
            if not texture_path.exists():
                problems.append(f"Textura de entidad ausente: {java_file.relative_to(ROOT)} -> {texture_id}.png")

    # Blockstate model references must resolve to JSON models.
    blockstate_files = sorted((RESOURCES / "assets" / MOD_ID / "blockstates").glob("*.json"))
    for path in blockstate_files:
        blockstate = parsed.get(path)
        if not isinstance(blockstate, dict):
            continue
        refs: list[str] = []
        def collect_models(value):
            if isinstance(value, dict):
                if isinstance(value.get("model"), str): refs.append(value["model"])
                for child in value.values(): collect_models(child)
            elif isinstance(value, list):
                for child in value: collect_models(child)
        collect_models(blockstate)
        for ref in refs:
            namespace, model_id = ref.split(":", 1) if ":" in ref else (MOD_ID, ref)
            if not resource_path(namespace, "models", model_id).exists():
                problems.append(f"Modelo de blockstate ausente: {path.relative_to(ROOT)} -> {ref}")

    nbt_files = sorted((RESOURCES / "data" / MOD_ID / "structures").glob("*.nbt"))
    flesh_spawner_found = False
    for path in nbt_files:
        try:
            root = read_nbt(path)
            size, palette, blocks = root["size"], root["palette"], root["blocks"]
            if root.get("DataVersion") != 3465:
                raise ValueError("DataVersion esperado para Minecraft 1.20.1: 3465")
            if len(size) != 3 or not palette:
                raise ValueError("Tamaño o paleta vacíos")
            for block in blocks:
                if not 0 <= block["state"] < len(palette):
                    raise ValueError("Índice de estado fuera de la paleta")
                pos = block["pos"]
                if any(not 0 <= pos[i] < size[i] for i in range(3)):
                    raise ValueError(f"Bloque fuera del tamaño: {pos}")
                block_nbt = block.get("nbt") or {}
                if block_nbt.get("id") == "minecraft:chest":
                    loot = block_nbt.get("LootTable", "")
                    loot_path = RESOURCES / "data" / MOD_ID / "loot_tables" / "chests" / (loot.split(":", 1)[-1].removeprefix("chests/") + ".json")
                    if not loot.startswith(f"{MOD_ID}:chests/") or not loot_path.exists():
                        problems.append(f"Tabla de botín no válida o ausente en {path.name}: {loot}")
                if block_nbt.get("id") == "minecraft:mob_spawner":
                    spawn_id = block_nbt.get("SpawnData", {}).get("entity", {}).get("id", "")
                    if spawn_id == f"{MOD_ID}:flesh_boss":
                        flesh_spawner_found = True
        except Exception as exc:
            problems.append(f"NBT inválido: {path.relative_to(ROOT)}: {exc}")

    if not flesh_spawner_found:
        problems.append("No se encontró el spawner del Guardián Mutante en las estructuras NBT.")

    if problems:
        for problem in problems:
            print("ERROR:", problem)
        print(f"\nFalló la validación: {len(problems)} problema(s).")
        return 1

    print(f"OK: {len(json_files)} JSON, {len(model_files)} modelos, {len(blockstate_files)} blockstates, "
          f"{len(nbt_files)} estructuras NBT y sus referencias revisadas.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
