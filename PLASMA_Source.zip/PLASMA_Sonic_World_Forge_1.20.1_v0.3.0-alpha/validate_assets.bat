@echo off
setlocal
cd /d "%~dp0"
python tools\validate_assets.py
if errorlevel 1 (
  echo.
  echo La validacion encontro errores.
  pause
  exit /b 1
)
echo.
echo Recursos validos. Esto no sustituye una compilacion ni una prueba en Minecraft.
pause
