@echo off
setlocal
set "PROJECT_DIR=%~dp0"
set "BOOTSTRAP_DIR=%PROJECT_DIR%.gradle-bootstrap"
set "GRADLE_HOME=%BOOTSTRAP_DIR%\gradle-8.8"

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Gradle 8.8 no esta instalado. Ejecuta primero build.bat o deja que se descargue ahora.
  if not exist "%BOOTSTRAP_DIR%" mkdir "%BOOTSTRAP_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; $zip=Join-Path '%BOOTSTRAP_DIR%' 'gradle-8.8-bin.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.8-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath '%BOOTSTRAP_DIR%' -Force; Remove-Item -LiteralPath $zip -Force"
  if errorlevel 1 (
    echo No se pudo descargar Gradle. Revisa tu conexion a Internet.
    pause
    exit /b 1
  )
)

call "%GRADLE_HOME%\bin\gradle.bat" runClient --stacktrace
if errorlevel 1 (
  echo.
  echo No se pudo iniciar el cliente de desarrollo. Revisa JDK 17 y el registro de Gradle.
  pause
  exit /b 1
)
pause
