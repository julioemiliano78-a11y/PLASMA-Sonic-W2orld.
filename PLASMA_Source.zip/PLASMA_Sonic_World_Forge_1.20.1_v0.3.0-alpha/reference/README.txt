PLASMA_REFERENCE_SHEET.png: hoja de referencia original del personaje, usada para proporciones y diseño general.
PLASMA_COLOR_REFERENCE.png: imagen adicional compartida por el usuario, usada solo como referencia de color y rostro. La ropa de esa imagen no forma parte del diseño de PLASMA.
