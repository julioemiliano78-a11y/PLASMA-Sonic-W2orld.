# Cambios — 0.3.0-alpha

- Consolidación del proyecto como PLASMA: Sonic World para Forge 1.20.1.
- Cuatro biomas temáticos: Green Hill, Costa Esmeralda, Ciudad Crepuscular y Green Hill Infectado.
- Seis estructuras: aldea, ruinas urbanas, mina, dungeon de carne, refugio mobiano y santuario de la Esmeralda Maestra.
- Catorce variantes de mobianos adoptables, alimento preferido, misiones, recompensas, habilidades de apoyo y descendientes.
- Molino, diamante pulido, polvo y pastilla familiar azul; 35 variaciones procedurales de poses sociales.
- Hogares mobianos ampliables de 2 a 12 residentes y partículas de corazón sobre casas ocupadas.
- Progresión de PLASMA: huevo, larva, crisálida, larva oscura, pupa, joven, forma Mania y adulto.
- Acecho de terror en los primeros días y jefe hostil PLASMA de 2000 HP al día 500 si el jugador no lo adoptó.
- Amy crasheada como variante especial que puede apaciguar al jefe.
- Tres formas infectadas y Guardián Mutante de la dungeon de carne.
- Minerales, fragmentos, cultivos, botas de Sonic, armas/reliquias de personajes y mejoras del Santuario de la Esmeralda Maestra.
- Guía de campo con capítulos desbloqueables mediante páginas encontradas.
- Trabajos simples de PLASMA adulto: agricultura, ordeño, minería de menas cercanas y construcción de una cabaña básica.
- Validación ampliada de JSON, referencias de texturas/modelos, blockstates, estructuras NBT y PNG.

## Pendiente de verificación externa

No se realizó compilación Gradle ni prueba de juego en esta máquina. La versión sigue siendo alfa y puede necesitar correcciones de compilación, balance, spawn rates, pathfinding, modelos y animaciones tras ejecutarla en Forge 1.20.1.
