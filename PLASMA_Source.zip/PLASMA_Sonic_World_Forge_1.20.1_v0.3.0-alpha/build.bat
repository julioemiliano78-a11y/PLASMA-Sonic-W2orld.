@echo off
setlocal
set "PROJECT_DIR=%~dp0"
set "BOOTSTRAP_DIR=%PROJECT_DIR%.gradle-bootstrap"
set "GRADLE_HOME=%BOOTSTRAP_DIR%\gradle-8.8"

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Gradle 8.8 no esta instalado. Se descargara una copia local del distribuidor oficial.
  if not exist "%BOOTSTRAP_DIR%" mkdir "%BOOTSTRAP_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; $zip=Join-Path '%BOOTSTRAP_DIR%' 'gradle-8.8-bin.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.8-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath '%BOOTSTRAP_DIR%' -Force; Remove-Item -LiteralPath $zip -Force"
  if errorlevel 1 (
    echo No se pudo descargar Gradle. Revisa tu conexion a Internet.
    pause
    exit /b 1
  )
)

call "%GRADLE_HOME%\bin\gradle.bat" build --stacktrace
if errorlevel 1 (
  echo.
  echo La compilacion fallo. Comprueba que JDK 17 este instalado y que haya conexion a Internet.
  pause
  exit /b 1
)
echo.
echo JAR creado en build\libs\plasma_companion-0.3.0-alpha.jar
pause
